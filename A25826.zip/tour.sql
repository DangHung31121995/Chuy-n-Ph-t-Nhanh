-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2017 at 12:15 PM
-- Server version: 10.1.19-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tour`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `User` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`User`, `Password`, `Email`, `Status`) VALUES
('admin', '25d55ad283aa400af464c76d713c07ad', 'smallboy329@gmail.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `chitietdat`
--

CREATE TABLE `chitietdat` (
  `MaDat` int(10) NOT NULL,
  `MaTour` char(10) NOT NULL,
  `CapKS` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chitietdat`
--

INSERT INTO `chitietdat` (`MaDat`, `MaTour`, `CapKS`) VALUES
(2, 'DL02', '4*');

--
-- Triggers `chitietdat`
--
DELIMITER $$
CREATE TRIGGER `Up` AFTER INSERT ON `chitietdat` FOR EACH ROW Update ttour set SoCho=SoCho-1 WHERE MaTour=NEW.MaTour
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `Up1` AFTER DELETE ON `chitietdat` FOR EACH ROW UPDATE ttour set SoCho=SoCho+1
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `dattour`
--

CREATE TABLE `dattour` (
  `MaDat` int(20) NOT NULL,
  `MaTV` int(20) NOT NULL,
  `NgayDat` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `dattour`
--

INSERT INTO `dattour` (`MaDat`, `MaTV`, `NgayDat`) VALUES
(1, 0, '2017-03-01 15:34:12.000000'),
(2, 0, '2017-03-01 16:55:30.000000'),
(3, 0, '2017-03-01 17:31:56.000000');

-- --------------------------------------------------------

--
-- Table structure for table `diemden`
--

CREATE TABLE `diemden` (
  `MaDD` char(10) NOT NULL,
  `MaLoai` char(10) NOT NULL,
  `TenDD` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diemden`
--

INSERT INTO `diemden` (`MaDD`, `MaLoai`, `TenDD`) VALUES
('CP01', 'NN01', 'Campuchia'),
('DL01', 'TN01', 'ÄÃ  Láº¡t'),
('HL01', 'TN01', 'Háº¡ Long'),
('HQ01', 'NN01', 'HÃ n Quá»‘c'),
('ID01', 'NN01', 'Indonexia'),
('NB01', 'NN01', 'Nháº­t Báº£n'),
('NT01', 'TN01', 'Nha Trang'),
('TL01', 'NN01', 'ThÃ¡i Lan');

-- --------------------------------------------------------

--
-- Table structure for table `diemkh`
--

CREATE TABLE `diemkh` (
  `MaKH` char(10) NOT NULL,
  `TenDiem` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `diemkh`
--

INSERT INTO `diemkh` (`MaKH`, `TenDiem`) VALUES
('CT01', 'Cáº§n ThÆ¡'),
('DN01', 'ÄÃ  Náºµng'),
('H01', 'Huáº¿'),
('HCM01', 'Há»“ ChÃ­ Minh'),
('HN01', 'HÃ  Ná»™i'),
('HP01', 'Háº£i PhÃ²ng'),
('QN01', 'Quáº£ng Ninh');

-- --------------------------------------------------------

--
-- Table structure for table `loaitour`
--

CREATE TABLE `loaitour` (
  `MaLoai` char(10) NOT NULL,
  `TenLoai` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `loaitour`
--

INSERT INTO `loaitour` (`MaLoai`, `TenLoai`) VALUES
('NN01', 'NgoÃ i NÆ°á»›c'),
('TN01', 'Trong NÆ°á»›c');

-- --------------------------------------------------------

--
-- Table structure for table `thanhvien`
--

CREATE TABLE `thanhvien` (
  `MaTV` int(10) NOT NULL,
  `User` varchar(30) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `HoTen` varchar(30) NOT NULL,
  `GioiTinh` varchar(20) NOT NULL,
  `DiaChi` varchar(30) NOT NULL,
  `SoCMT` int(11) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `SoDT` char(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `thanhvien`
--

INSERT INTO `thanhvien` (`MaTV`, `User`, `Password`, `HoTen`, `GioiTinh`, `DiaChi`, `SoCMT`, `Email`, `SoDT`) VALUES
(0, 'kute', 'e10adc3949ba59abbe56e057f20f883e', 'Nguyá»…n VÄƒn An', 'Nam', 'HÃ  Ná»™i', 123456789, 'bach@gmail.com', '0984124351'),
(1, 'phu', 'e10adc3949ba59abbe56e057f20f883e', 'phÃº', 'Nam', 'HÃ  Ná»™i', 123456789, 'phu@gmail.com', '01635240124'),
(2, 'kute1', 'e10adc3949ba59abbe56e057f20f883e', 'hieu', 'Nam', 'HÃ  Ná»™i', 123456789, 'bach1@gmail.com', '09841243511'),
(3, 'kute2', 'e10adc3949ba59abbe56e057f20f883e', 'phu', 'Nam', 'HÃ  Ná»™i', 123456789, 'bach2@gmail.com', '098412435111');

-- --------------------------------------------------------

--
-- Table structure for table `tintuc`
--

CREATE TABLE `tintuc` (
  `MaTin` char(10) NOT NULL,
  `TenTin` varchar(50) NOT NULL,
  `Anh` varchar(50) NOT NULL,
  `NDTomTat` text NOT NULL,
  `NoiDung` text NOT NULL,
  `NgayGui` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tintuc`
--

INSERT INTO `tintuc` (`MaTin`, `TenTin`, `Anh`, `NDTomTat`, `NoiDung`, `NgayGui`) VALUES
('T01', 'Ngáº¯m thiÃªn Ä‘Æ°á»ng hoa xuÃ¢n tháº¿ giá»›i', 'views/images/H1.jpg', 'VÃ  mÃ¹a xuÃ¢n sáº½ cÃ ng tuyá»‡t hÆ¡n náº¿u báº¡n chu du kháº¯p tháº¿ giá»›i ngáº¯m hoa anh Ä‘Ã o, tulip ná»Ÿ rá»™ tá»« giá»¯a thÃ¡ng 3 Ä‘áº¿n cuá»‘i thÃ¡ng 5. Má»™t tháº¿ giá»›i hoa xuÃ¢n Ä‘áº¹p lung linh, khiáº¿n bao lá»¯ khÃ¡ch nao lÃ²ng khi chÃ¬m ngáº­p trong biá»ƒn sáº¯c mÃ u kiá»u diá»…m. HÃ£y khá»Ÿi Ä‘á»™ng chuyáº¿n du xuÃ¢n cá»§a báº¡n báº±ng viá»‡c khÃ¡m phÃ¡ váº» Ä‘áº¹p rá»±c rá»¡ cá»§a nhá»¯ng lá»… há»™i hoa áº¥n tÆ°á»£ng nháº¥t tháº¿ giá»›i dÆ°á»›i Ä‘Ã¢y nhÃ©!', '&lt;p&gt;&lt;img alt=&quot;Kairakuen&quot; src=&quot;views/images/H1.jpg&quot; style=&quot;border-style:solid; border-width:1px; float:left; height:100px; width:150px&quot; /&gt;V&amp;agrave; m&amp;ugrave;a xu&amp;acirc;n sáº½ c&amp;agrave;ng tuyá»‡t hÆ¡n náº¿u báº¡n chu du kháº¯p tháº¿ giá»›i ngáº¯m hoa anh Ä‘&amp;agrave;o, tulip ná»Ÿ rá»™ tá»« giá»¯a th&amp;aacute;ng 3 Ä‘áº¿n cuá»‘i th&amp;aacute;ng 5. Má»™t tháº¿ giá»›i hoa xu&amp;acirc;n Ä‘áº¹p lung linh, khiáº¿n bao lá»¯ kh&amp;aacute;ch nao l&amp;ograve;ng khi ch&amp;igrave;m ngáº­p trong biá»ƒn sáº¯c m&amp;agrave;u kiá»u diá»…m. H&amp;atilde;y khá»Ÿi Ä‘á»™ng chuyáº¿n du xu&amp;acirc;n cá»§a báº¡n báº±ng viá»‡c kh&amp;aacute;m ph&amp;aacute; váº» Ä‘áº¹p rá»±c rá»¡ cá»§a nhá»¯ng lá»… há»™i hoa áº¥n tÆ°á»£ng nháº¥t tháº¿ giá»›i dÆ°á»›i Ä‘&amp;acirc;y nh&amp;eacute;!&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Du xu&amp;acirc;n theo nhá»¯ng c&amp;aacute;nh hoa anh Ä‘&amp;agrave;o&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/Kairakuen.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Hoa anh Ä‘&amp;agrave;o á»Ÿ xá»© Ph&amp;ugrave; Tang mang m&amp;agrave;u há»“ng pháº¥n l&amp;atilde;ng máº¡n báº¯t Ä‘áº§u ná»Ÿ tá»« th&amp;aacute;ng Gi&amp;ecirc;ng táº¡i Okinawa k&amp;eacute;o d&amp;agrave;i cho Ä‘áº¿n cuá»‘i th&amp;aacute;ng 5 táº¡i&amp;nbsp;&lt;a href=&quot;https://travel.com.vn/chau-a/tour-hokkaido.aspx&quot;&gt;Hokkaido&lt;/a&gt;, nhÆ°ng chá»‰ thá»±c sá»± khoe sáº¯c tuyá»‡t Ä‘áº¹p v&amp;agrave;o cuá»‘i th&amp;aacute;ng 3, Ä‘áº§u th&amp;aacute;ng 4. Du kh&amp;aacute;ch thÆ°á»ng táº­p trung thÆ°á»Ÿng ngoáº¡n hoa Ä‘&amp;ocirc;ng nháº¥t l&amp;agrave; á»Ÿ c&amp;ocirc;ng vi&amp;ecirc;n Matsumae (Hokkaido), c&amp;ocirc;ng vi&amp;ecirc;n Ueno (&lt;a href=&quot;https://travel.com.vn/chau-a/tour-tokyo.aspx&quot;&gt;Tokyo&lt;/a&gt;), l&amp;acirc;u Ä‘&amp;agrave;i&amp;nbsp;&lt;a href=&quot;https://travel.com.vn/chau-a/tour-osaka.aspx&quot;&gt;Osaka&lt;/a&gt;&amp;nbsp;(Osaka), n&amp;uacute;i Ph&amp;uacute; SÄ©... V&amp;agrave;o m&amp;ugrave;a lá»… há»™i, ngÆ°á»i d&amp;acirc;n thÆ°á»ng tá»• chá»©c picnic, qu&amp;acirc;y quáº§n Äƒn uá»‘ng v&amp;agrave; ca h&amp;aacute;t dÆ°á»›i cá»™i Ä‘&amp;agrave;o gi&amp;agrave;&amp;hellip;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/Kairakuen1.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;á»ž H&amp;agrave;n Quá»‘c, do kh&amp;iacute; háº­u tÆ°Æ¡ng Ä‘á»“ng vá»›i&amp;nbsp;&lt;a href=&quot;https://travel.com.vn/chau-a/tour-nhat-ban.aspx&quot;&gt;Nháº­t Báº£n&lt;/a&gt;&amp;nbsp;n&amp;ecirc;n hoa anh Ä‘&amp;agrave;o cÅ©ng xuáº¥t hiá»‡n c&amp;ugrave;ng thá»i Ä‘iá»ƒm. Jinhae l&amp;agrave; lá»… há»™i hoa anh Ä‘&amp;agrave;o lá»›n nháº¥t táº¡i&amp;nbsp;&lt;a href=&quot;https://travel.com.vn/chau-a/tour-han-quoc.aspx&quot;&gt;H&amp;agrave;n Quá»‘c&lt;/a&gt;, thu h&amp;uacute;t h&amp;agrave;ng triá»‡u lÆ°á»£t kh&amp;aacute;ch má»—i nÄƒm. Lá»… há»™i k&amp;eacute;o d&amp;agrave;i 10 ng&amp;agrave;y, báº¡n thoáº£i m&amp;aacute;i chi&amp;ecirc;m ngÆ°á»¡ng nhá»¯ng con Ä‘Æ°á»ng hoa báº¥t táº­n dá»c Ä‘Æ°á»ng ray xe lá»­a k&amp;egrave;m theo m&amp;agrave;n biá»ƒu diá»…n Ä‘Æ°á»ng phá»‘, lá»… há»™i, diá»…u h&amp;agrave;nh qu&amp;acirc;n sá»±&amp;hellip; Ngo&amp;agrave;i ra, á»Ÿ Seoul cÅ©ng c&amp;oacute; Ä‘Æ°á»ng hoa Yunjungno vá»›i h&amp;agrave;ng trÄƒm cá»™i anh Ä‘&amp;agrave;o trá»“ng tháº³ng táº¯p l&amp;agrave; nÆ¡i ngáº¯m hoa l&amp;yacute; tÆ°á»Ÿng nháº¥t&amp;hellip; Hoa anh Ä‘&amp;agrave;o á»Ÿ Ä&amp;agrave;i Loan láº¡i ná»Ÿ sá»›m hÆ¡n v&amp;agrave;o Ä‘áº§u th&amp;aacute;ng 2. C&amp;ocirc;ng vi&amp;ecirc;n DÆ°Æ¡ng Minh SÆ¡n l&amp;agrave; Ä‘á»‹a Ä‘iá»ƒm thu h&amp;uacute;t du kh&amp;aacute;ch Ä‘áº¿n ngáº¯m hoa nhiá»u nháº¥t.&amp;nbsp;&lt;/p&gt;\r\n', '2017-01-02 19:00:00'),
('T02', 'Valentine nÃ y báº¡n Ä‘i Ä‘Ã¢u?', 'views/images/Valen.jpg', 'NgÃ y lá»… tÃ¬nh nhÃ¢n Valentine lÃ  thá»i gian lÃ½ tÆ°á»Ÿng Ä‘á»ƒ cÃ¡c Ä‘Ã´i uyÃªn Æ°Æ¡ng thá»±c hiá»‡n chuyáº¿n du lá»‹ch ngá»t ngÃ o. CÃ²n vá»›i nhá»¯ng cáº·p vá»£ chá»“ng, Ä‘Ã¢y cÃ²n lÃ  cÆ¡ há»™i Ä‘á»ƒ â€œhÃ¢m nÃ³ngâ€ tÃ¬nh yÃªu sau bao lo toan thÆ°á»ng nháº­t. Náº¿u cÃ²n Ä‘áº¯n Ä‘o lá»±a chá»n, hÃ£y Ä‘á»ƒ Vietravel tÆ° váº¥n vÃ  chu toÃ n giÃºp báº¡n nhÃ©!', '&lt;p&gt;&lt;img alt=&quot;VaLen&quot; src=&quot;views/images/Valen.jpg&quot; style=&quot;border-style:solid; border-width:1px; float:left; height:120px; width:192px&quot; /&gt;Ng&amp;agrave;y lá»… t&amp;igrave;nh nh&amp;acirc;n Valentine l&amp;agrave; thá»i gian l&amp;yacute; tÆ°á»Ÿng Ä‘á»ƒ c&amp;aacute;c Ä‘&amp;ocirc;i uy&amp;ecirc;n Æ°Æ¡ng thá»±c hiá»‡n chuyáº¿n du lá»‹ch ngá»t ng&amp;agrave;o. C&amp;ograve;n vá»›i nhá»¯ng cáº·p vá»£ chá»“ng, Ä‘&amp;acirc;y c&amp;ograve;n l&amp;agrave; cÆ¡ há»™i Ä‘á»ƒ &amp;ldquo;h&amp;acirc;m n&amp;oacute;ng&amp;rdquo; t&amp;igrave;nh y&amp;ecirc;u sau bao lo toan thÆ°á»ng nháº­t. Náº¿u c&amp;ograve;n Ä‘áº¯n Ä‘o lá»±a chá»n, h&amp;atilde;y Ä‘á»ƒ Vietravel tÆ° váº¥n v&amp;agrave; chu to&amp;agrave;n gi&amp;uacute;p báº¡n nh&amp;eacute;!&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Háº¡ Long&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;HL&quot; src=&quot;views/images/HL.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;ÄÆ°á»£c National Geographic b&amp;igrave;nh chá»n l&amp;agrave; má»™t trong 10 Ä‘iá»ƒm Ä‘áº¿n háº¥p dáº«n nháº¥t cho ng&amp;agrave;y Valentine,&amp;nbsp;Háº¡ Long&amp;nbsp;&amp;ldquo;Ä‘Æ°á»£c l&amp;ograve;ng&amp;rdquo; c&amp;aacute;c Ä‘&amp;ocirc;i uy&amp;ecirc;n Æ°Æ¡ng bá»Ÿi m&amp;agrave;u xanh biáº¿c cá»§a biá»ƒn trá»i, váº» Ä‘áº¹p kinh ngáº¡c cá»§a h&amp;agrave;ng ng&amp;agrave;n Ä‘áº£o Ä‘&amp;aacute; v&amp;agrave; hang Ä‘á»™ng tháº¡ch nhÅ©. Sáº½ l&amp;agrave; má»™t ng&amp;agrave;y t&amp;igrave;nh nh&amp;acirc;n ngá»t ng&amp;agrave;o khi ngon giáº¥c tr&amp;ecirc;n du thuyá»n sang trá»ng, Äƒn tá»‘i dÆ°á»›i ng&amp;agrave;n sao láº¥p l&amp;aacute;nh, c&amp;ugrave;ng ngáº¯m b&amp;igrave;nh minh ráº¡ng rá»¡.&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Sapa&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/SP.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Kh&amp;ocirc;ng chá»‰ h&amp;iacute;t thá»Ÿ kh&amp;ocirc;ng kh&amp;iacute; trong l&amp;agrave;nh, Ä‘&amp;ocirc;i báº¡n c&amp;ograve;n c&amp;oacute; nhá»¯ng bá»©c áº£nh áº¥n tÆ°á»£ng giá»¯a nhá»¯ng thá»­a ruá»™ng báº­c thang cao ng&amp;uacute;t ng&amp;agrave;n, h&amp;ograve;a c&amp;ugrave;ng mu&amp;ocirc;n sáº¯c m&amp;agrave;u chá»£ phi&amp;ecirc;n rá»±c rá»¡. Má»™t buá»•i tá»‘i se láº¡nh, ngá»“i b&amp;ecirc;n báº¿p lá»­a há»“ng xu&amp;yacute;t xoa Äƒn Ä‘á»“ nÆ°á»›ng, ngáº¯m thá»‹ tráº¥n phá»§ trong sÆ°Æ¡ng m&amp;ugrave; hay dáº¡o chÆ¡i Ä‘&amp;ecirc;m chá»£ t&amp;igrave;nh&amp;hellip; sáº½ l&amp;agrave; nhá»¯ng dáº¥u áº¥n kh&amp;oacute; phai trong l&amp;ograve;ng lá»¯ kh&amp;aacute;ch.&lt;/p&gt;\r\n', '2017-02-10 08:00:00'),
('T03', 'HÃ nh hÆ°Æ¡ng cáº§u phÃºc Ä‘áº§u nÄƒm', 'views/images/BD.jpg', 'NgÃ y xuÃ¢n lá»… Pháº­t lÃ  nÃ©t Ä‘áº¹p vÄƒn hÃ³a tÃ¢m linh cá»§a ngÆ°á»i Viá»‡t. NgoÃ i viá»‡c cáº§u bÃ¬nh an, háº¡nh phÃºc cho gia Ä‘áº¡o, khÃ¡ch hÃ nh hÆ°Æ¡ng cÃ²n vÃ£n cáº£nh chÃ¹a Ä‘á»ƒ tÃ¬m vá» sá»± an yÃªn, thanh tá»‹nh. DÆ°á»›i Ä‘Ã¢y lÃ  má»™t sá»‘ gá»£i Ã½ thÃº vá»‹ dÃ nh cho báº¡n vÃ o mÃ¹a lá»… há»™i rá»™n rÃ ng nÃ y.', '&lt;h3&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/BD.jpg&quot; style=&quot;float:left; height:120px; width:211px&quot; /&gt;&amp;nbsp;Ng&amp;agrave;y xu&amp;acirc;n lá»… Pháº­t l&amp;agrave; n&amp;eacute;t Ä‘áº¹p vÄƒn h&amp;oacute;a t&amp;acirc;m linh cá»§a ngÆ°á»i Viá»‡t. Ngo&amp;agrave;i viá»‡c cáº§u b&amp;igrave;nh an, háº¡nh ph&amp;uacute;c cho gia Ä‘áº¡o, kh&amp;aacute;ch h&amp;agrave;nh hÆ°Æ¡ng c&amp;ograve;n v&amp;atilde;n cáº£nh ch&amp;ugrave;a Ä‘á»ƒ t&amp;igrave;m vá» sá»± an y&amp;ecirc;n, thanh tá»‹nh. DÆ°á»›i Ä‘&amp;acirc;y l&amp;agrave; má»™t sá»‘ gá»£i &amp;yacute; th&amp;uacute; vá»‹ d&amp;agrave;nh cho báº¡n v&amp;agrave;o m&amp;ugrave;a lá»… há»™i rá»™n r&amp;agrave;ng n&amp;agrave;y.&lt;/h3&gt;\r\n\r\n&lt;h3&gt;&amp;nbsp;&lt;/h3&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Non thi&amp;ecirc;ng Y&amp;ecirc;n Tá»­ (Quáº£ng Ninh)&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;h2&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp;&lt;img alt=&quot;&quot; src=&quot;views/images/YT.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;Quáº§n thá»ƒ danh tháº¯ng gá»“m há»‡ thá»‘ng c&amp;aacute;c di t&amp;iacute;ch vÄƒn h&amp;oacute;a, lá»‹ch sá»­ gáº¯n liá»n vá»›i sá»± h&amp;igrave;nh th&amp;agrave;nh, v&amp;agrave; ph&amp;aacute;t triá»ƒn cá»§a thiá»n ph&amp;aacute;i Tr&amp;uacute;c L&amp;acirc;m. H&amp;agrave;nh tr&amp;igrave;nh vá»&amp;nbsp;Y&amp;ecirc;n Tá»­&amp;nbsp;tá»±a nhÆ° Ä‘áº¿n vá»›i cá»•ng trá»i. Du kh&amp;aacute;ch sáº½ chi&amp;ecirc;m b&amp;aacute;i ch&amp;ugrave;a Tr&amp;igrave;nh, ch&amp;ugrave;a Suá»‘i Táº¯m, ch&amp;ugrave;a Cáº§m Thá»±c, ch&amp;ugrave;a L&amp;acirc;n, ch&amp;ugrave;a Giáº£i Oan, ch&amp;ugrave;a Hoa Y&amp;ecirc;n, ch&amp;ugrave;a Má»™t M&amp;aacute;i, ch&amp;ugrave;a Báº£o S&amp;aacute;i, ch&amp;ugrave;a V&amp;acirc;n Ti&amp;ecirc;u v&amp;agrave; cuá»‘i c&amp;ugrave;ng l&amp;agrave; ch&amp;ugrave;a Äá»“ng. Táº¡i&amp;nbsp;Y&amp;ecirc;n Tá»­&amp;nbsp;c&amp;ograve;n c&amp;oacute; Báº£o tÆ°á»£ng Pháº­t Ho&amp;agrave;ng Tráº§n Nh&amp;acirc;n T&amp;ocirc;ng trong tÆ° tháº¿ ngá»“i thiá»n tr&amp;ecirc;n Ä‘&amp;agrave;i sen, cao 12,6m, Ä‘Æ°á»£c Ä‘&amp;uacute;c tá»« 138 táº¥n Ä‘á»“ng báº±ng ká»¹ thuáº­t Ä‘á»• liá»n khá»‘i, Ä‘&amp;uacute;c ná»•i trá»±c tiáº¿p.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;h2 style=&quot;font-style:normal&quot;&gt;&lt;em&gt;Ch&amp;ugrave;a B&amp;aacute;i Ä&amp;iacute;nh (Ninh B&amp;igrave;nh)&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &amp;nbsp; &lt;img alt=&quot;&quot; src=&quot;views/images/BD2.jpg&quot; style=&quot;height:457px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Náº±m men theo sÆ°á»n n&amp;uacute;i, giá»¯a má»™t thung lÅ©ng m&amp;ecirc;nh m&amp;ocirc;ng há»“ v&amp;agrave; n&amp;uacute;i Ä‘&amp;aacute;, ch&amp;ugrave;a B&amp;aacute;i Ä&amp;iacute;nh sá»Ÿ há»¯u nhiá»u ká»· lá»¥c: ch&amp;ugrave;a c&amp;oacute; tÆ°á»£ng Pháº­t báº±ng Ä‘á»“ng d&amp;aacute;t v&amp;agrave;ng lá»›n nháº¥t ch&amp;acirc;u &amp;Aacute;, ch&amp;ugrave;a c&amp;oacute; h&amp;agrave;nh lang La H&amp;aacute;n d&amp;agrave;i nháº¥t ch&amp;acirc;u &amp;Aacute;, ch&amp;ugrave;a c&amp;oacute; tÆ°á»£ng Di láº·c báº±ng Ä‘á»“ng lá»›n nháº¥t Ä&amp;ocirc;ng Nam &amp;Aacute;... Nhá»¯ng pho tÆ°á»£ng, th&amp;aacute;p chu&amp;ocirc;ng táº¡i Ä‘&amp;acirc;y Ä‘á»u cháº¡m Ä‘áº¿n Ä‘á»‰nh cao cá»§a nghá»‡ thuáº­t Ä‘i&amp;ecirc;u kháº¯c. H&amp;ograve;a c&amp;ugrave;ng quan cáº£nh thi&amp;ecirc;n nhi&amp;ecirc;n, quáº§n thá»ƒ ch&amp;ugrave;a B&amp;aacute;i Ä&amp;iacute;nh xá»©ng Ä‘&amp;aacute;ng Ä‘Æ°á»£c gá»i báº±ng c&amp;aacute;i t&amp;ecirc;n hoa má»¹: &amp;ldquo;bá»“ng lai ti&amp;ecirc;n cáº£nh&amp;rdquo;.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n', '2017-02-06 09:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `ttour`
--

CREATE TABLE `ttour` (
  `MaTour` char(10) NOT NULL,
  `MaKH` char(10) NOT NULL,
  `MaLoai` char(10) NOT NULL,
  `MaDD` char(10) NOT NULL,
  `TenTour` varchar(100) NOT NULL,
  `Anh` varchar(50) NOT NULL,
  `GTTour` varchar(500) NOT NULL,
  `GiaTour` decimal(10,0) NOT NULL,
  `NoiDung` text NOT NULL,
  `NgayKhoiHanh` datetime NOT NULL,
  `NgayVe` datetime NOT NULL,
  `SoCho` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ttour`
--

INSERT INTO `ttour` (`MaTour`, `MaKH`, `MaLoai`, `MaDD`, `TenTour`, `Anh`, `GTTour`, `GiaTour`, `NoiDung`, `NgayKhoiHanh`, `NgayVe`, `SoCho`) VALUES
('DL01', 'HN01', 'TN01', 'HL01', 'Du thuyá»n Háº¡ Long Golden Cruise 5*', 'views/images/HL.jpg', 'Vá»‹nh Háº¡ Long nÆ¡i rá»“ng Ä‘Ã¡p xuá»‘ng, lÃ  danh tháº¯ng quá»‘c gia Ä‘Æ°á»£c xáº¿p háº¡ng tá»« nÄƒm 1962. Háº¡ Long cÃ³ 1.969 hÃ²n Ä‘áº£o, lÃ´ nhÃ´ trÃªn máº·t biá»ƒn, ná»•i tiáº¿ng nháº¥t lÃ  cÃ¡c hÃ²n LÆ° HÆ°Æ¡ng, GÃ  Chá»i, CÃ¡nh Buá»“m, MÃ¢m XÃ´i, Ä‘áº£o Ngá»c Vá»«ng, Ti Tá»‘p, Tuáº§n ChÃ¢u. Háº¡ Long nhÆ° bá»©c tranh thá»§y máº·c khá»•ng lá»“, tuyá»‡t Ä‘áº¹p, xá»©ng Ä‘Ã¡ng lÃ  biá»ƒu tÆ°á»£ng du lá»‹ch Viá»‡t Nam.', '3590000', '&lt;p&gt;Ng&amp;agrave;y 1 : H&amp;agrave; Ná»™i - Háº¡ Long (Ä‚n trÆ°a, chiá»u)&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;HL&quot; src=&quot;views/images/HL1.jpg&quot; style=&quot;border-style:solid; border-width:1px; height:168px; margin-left:150px; margin-right:150px; width:300px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;9:00Ä&amp;oacute;n táº¡i sá»‘ 03 Hai B&amp;agrave; TrÆ°ng. Xe khá»Ÿi h&amp;agrave;nh Ä‘i Háº¡ Long&lt;br /&gt;\r\n12:00 &amp;ndash; 12:30&lt;br /&gt;\r\nÄ&amp;oacute;n kh&amp;aacute;ch táº¡i cáº£ng t&amp;agrave;u du lá»‹ch Quá»‘c Táº¿ Tuáº§n Ch&amp;acirc;u v&amp;agrave; l&amp;agrave;m thá»§ tá»¥c nháº­n t&amp;agrave;u v&amp;agrave; cabin&lt;br /&gt;\r\n13:00 &amp;ndash; 14:30&lt;br /&gt;\r\nÄ‚n trÆ°a kiá»ƒu set menu tr&amp;ecirc;n t&amp;agrave;u vá»›i háº£i sáº£n tÆ°Æ¡i sá»‘ng v&amp;agrave; Ä‘i qua h&amp;ograve;n Äá»‰nh HÆ°Æ¡ng, h&amp;ograve;n Ch&amp;oacute; Ä&amp;aacute;,&amp;nbsp; h&amp;ograve;n G&amp;agrave; Chá»i&lt;br /&gt;\r\n15:00 &amp;ndash; 16:00&lt;br /&gt;\r\nThÄƒm hang Sá»­ng sá»‘t &amp;ndash; má»™t trong nhá»¯ng hang Ä‘á»™ng Ä‘áº¹p nháº¥t Háº¡ long.&lt;br /&gt;\r\n16:30 &amp;ndash; 18:00&lt;br /&gt;\r\nTrekking tr&amp;ecirc;n n&amp;uacute;i Titop ngáº¯m to&amp;agrave;n vá»‹nh Háº¡ long v&amp;agrave; táº¯m biá»ƒn táº¡i b&amp;atilde;i táº¯m Titop hoáº·c thu&amp;ecirc; kayaking Ä‘á»ƒ ngáº¯m vá»‹nh Háº¡ long&lt;br /&gt;\r\n19:00 &amp;ndash; 20:30&lt;br /&gt;\r\nKh&amp;aacute;ch Äƒn tá»‘i vá»›i c&amp;aacute;c m&amp;oacute;n háº£i sáº£n Háº¡ long&lt;br /&gt;\r\n20:30 &amp;ndash; 11:30&lt;br /&gt;\r\nChÆ°Æ¡ng tr&amp;igrave;nh phim hoáº·c c&amp;acirc;u má»±c vá» Ä‘&amp;ecirc;m khi c&amp;oacute; y&amp;ecirc;u cáº§u.&lt;/p&gt;\r\n\r\n&lt;p&gt;Ng&amp;agrave;y 2 : H&amp;agrave; Ná»™i - Háº¡ Long (Ä‚n trÆ°a, chiá»u)&lt;br /&gt;\r\n&lt;img alt=&quot;HL2&quot; src=&quot;views/images/HL2.jpg&quot; style=&quot;border-style:solid; border-width:1px; height:200px; margin-left:150px; margin-right:150px; width:300px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;06:30 &amp;ndash; 07:00&lt;br /&gt;\r\nQu&amp;yacute; kh&amp;aacute;ch thá»±c dáº­y ngáº¯m b&amp;igrave;nh minh.&lt;br /&gt;\r\n07:00 &amp;ndash; 08:00&lt;br /&gt;\r\nÄ‚n s&amp;aacute;ng kiá»ƒu &amp;Acirc;u&lt;br /&gt;\r\n08:00 &amp;ndash; 09:00&lt;br /&gt;\r\nThÄƒm hang Luá»“n báº±ng thuyá»n nhá», cháº¡y qua h&amp;ograve;n Äáº§u NgÆ°á»i, h&amp;ograve;n Con R&amp;ugrave;a&lt;br /&gt;\r\n09:30&lt;br /&gt;\r\nL&amp;agrave;m thá»§ tá»¥c tráº£ ph&amp;ograve;ng v&amp;agrave; thanh to&amp;aacute;n h&amp;oacute;a Ä‘Æ¡n&lt;br /&gt;\r\n11:00&lt;br /&gt;\r\nQu&amp;yacute; kh&amp;aacute;ch tráº£ t&amp;agrave;u vá» nh&amp;agrave; h&amp;agrave;ng Cua v&amp;agrave;ng Äƒn trÆ°a hoáº·c Äƒn tr&amp;ecirc;n t&amp;agrave;u.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n', '2017-03-01 09:00:00', '2017-03-05 15:00:00', 10),
('DL02', 'HCM01', 'NN01', 'CP01', 'HÃ nh HÆ°Æ¡ng ThÃ¡nh Äá»‹a Kulen', 'views/images/MocBai .jpg', 'Campuchia lÃ  quá»‘c gia Ä‘Æ°á»£c má»‡nh danh â€œÄ‘áº¥t nÆ°á»›c chÃ¹a thÃ¡pâ€ chá»©a Ä‘á»±ng bao Ä‘iá»u bÃ­ áº©n lÃ m mÃª Ä‘áº¯m nhiá»u du khÃ¡ch. NÆ¡i áº¥y, váº» Ä‘áº¹p nguyÃªn sÆ¡ cá»§a nÃºi rá»«ng, váº» Ä‘áº¹p trong xanh cá»§a cÃ¡t biá»ƒn, dáº¥u áº¥n huyá»n bÃ­ cá»§a nhá»¯ng Ä‘á»n Ä‘Ã i cung Ä‘iá»‡n cá»• xÆ°a hay Ä‘Æ¡n giáº£n lÃ  ná»¥ cÆ°á»i há»“n háº­u cá»§a ngÆ°á»i dÃ¢n xá»© nÃ yâ€¦.cháº¯c háº³n sáº½ lÆ°u láº¡i cho du khÃ¡ch nhá»¯ng áº¥n tÆ°á»£ng khÃ³ phai.', '4490000', '&lt;h2&gt;&lt;em&gt;Ng&amp;agrave;y 1 : TP.Há»’ CH&amp;Iacute; MINH - Má»˜C B&amp;Agrave;I - SIEM REAP (Ä‚n ba bá»¯a)&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/MocBai .jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Xe v&amp;agrave; hÆ°á»›ng dáº«n vi&amp;ecirc;n Vietravel Ä‘&amp;oacute;n Qu&amp;yacute; kh&amp;aacute;ch táº¡i 190 Pasteur, Q.3, TP.HCM, khá»Ÿi h&amp;agrave;nh Ä‘áº¿n cá»­a kháº©u Má»™c B&amp;agrave;i. Ä‚n s&amp;aacute;ng tr&amp;ecirc;n Ä‘Æ°á»ng. Äáº¿n Má»™c B&amp;agrave;i, Qu&amp;yacute; kh&amp;aacute;ch l&amp;agrave;m thá»§ tá»¥c qua cá»­a kháº©u. Xe v&amp;agrave; hÆ°á»›ng dáº«n vi&amp;ecirc;n Ä‘á»‹a phÆ°Æ¡ng Ä‘&amp;oacute;n Ä‘o&amp;agrave;n v&amp;agrave; Ä‘Æ°a Ä‘i d&amp;ugrave;ng bá»¯a trÆ°a táº¡i nh&amp;agrave; h&amp;agrave;ng Ä‘á»‹a phÆ°Æ¡ng . Sau Ä‘&amp;oacute;, Qu&amp;yacute; kh&amp;aacute;ch tiáº¿p tá»¥c l&amp;ecirc;n Ä‘Æ°á»ng Ä‘i Siem Reap. Äáº¿n nÆ¡i, Qu&amp;yacute; kh&amp;aacute;ch vá» nháº­n ph&amp;ograve;ng táº¡i kh&amp;aacute;ch sáº¡n 3 sao. Ä‚n tá»‘i v&amp;agrave; tá»± do nghá»‰ ngÆ¡i.&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Ng&amp;agrave;y 2 : SIEM REAP &amp;ndash; TH&amp;Aacute;NH Äá»ŠA KULEN: (Ä‚n ba bá»¯a)&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/MocBai1.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Qu&amp;yacute; kh&amp;aacute;ch Äƒn s&amp;aacute;ng táº¡i kh&amp;aacute;ch sáº¡n. Xe Ä‘&amp;oacute;n Qu&amp;yacute; kh&amp;aacute;ch khá»Ÿi h&amp;agrave;nh Ä‘i C&amp;ocirc;ng Vi&amp;ecirc;n Quá»‘c Gia N&amp;uacute;i Kulen &amp;ndash; nÆ¡i Ä‘Æ°á»£c vua Jayavarman II chá»n l&amp;agrave;m kinh Ä‘&amp;ocirc; Ä‘áº§u ti&amp;ecirc;n cá»§a Ä‘áº¿ cháº¿ Khmer v&amp;agrave;o nÄƒm 802, má»Ÿ Ä‘áº§u cho ká»· nguy&amp;ecirc;n Angkor ch&amp;oacute;i lá»i. Du kh&amp;aacute;ch sáº½ len lá»i giá»¯a rá»«ng nguy&amp;ecirc;n sinh nhiá»‡t Ä‘á»›i, qua nhá»¯ng v&amp;ugrave;ng Ä‘&amp;aacute; nháº¥p nh&amp;ocirc;, láº¯t láº»o, gáº­p ghá»nh Ä‘á»ƒ Ä‘áº¿n vá»›i th&amp;aacute;nh Ä‘á»‹a h&amp;agrave;nh hÆ°Æ¡ng cá»§a ngÆ°á»i Khmer. Äáº¿n nÆ¡i, Ä‘o&amp;agrave;n tham quan Suá»‘i ng&amp;agrave;n lingas &amp;ndash; Ä‘Æ°á»£c biáº¿t Ä‘áº¿n nhÆ° má»™t d&amp;ograve;ng suá»‘i tháº§n th&amp;aacute;nh dÆ°á»›i triá»u Ä‘áº¡i trá»‹ v&amp;igrave; cá»§a vua Suryavarman I. Du kh&amp;aacute;ch sáº½ ngáº¡c nhi&amp;ecirc;n Ä‘áº¿n báº¥t ngá» vá»›i h&amp;agrave;ng ng&amp;agrave;n tÆ°á»£ng linga, yoni Ä‘Æ°á»£c táº¡c dÆ°á»›i l&amp;ograve;ng suá»‘i &amp;ndash; d&amp;ugrave; tráº£i qua hÆ¡n 1000 nÄƒm, nÆ°á»›c s&amp;ocirc;ng Ä‘&amp;atilde; kh&amp;ocirc;ng thá»ƒ b&amp;agrave;o m&amp;ograve;n Ä‘Æ°á»£c nhá»¯ng tuyá»‡t t&amp;aacute;c áº¥y, m&amp;agrave; c&amp;ograve;n l&amp;agrave;m cho ch&amp;uacute;ng trá»Ÿ n&amp;ecirc;n lung linh hÆ¡n, huyá»n b&amp;iacute; hÆ¡n. Táº¥t cáº£ Ä‘&amp;aacute; x&amp;acirc;y dá»±ng Ä‘á»n Angkor Ä‘á»u Ä‘Æ°á»£c khai th&amp;aacute;c tá»« miá»n Ä‘áº¥t linh thi&amp;ecirc;ng n&amp;agrave;y.&amp;nbsp;Qu&amp;yacute; kh&amp;aacute;ch di chuyá»ƒn l&amp;ecirc;n n&amp;uacute;i v&amp;agrave; tham quan Ch&amp;ugrave;a Pháº­t Lá»›n, Dáº¥u b&amp;agrave;n ch&amp;acirc;n Pháº­t in tr&amp;ecirc;n Ä‘&amp;aacute;, Giáº¿ng nÆ°á»›c tháº§n &amp;ndash; nÆ¡i tu&amp;ocirc;n tr&amp;agrave;o máº¡ch nÆ°á»›c trong váº¯t Ä‘Æ°á»£c ngÆ°á»i báº£n xá»© Ä‘á»‹nh danh l&amp;agrave; giáº¿ng thi&amp;ecirc;ng, Th&amp;aacute;c Phnom Kulen &amp;ndash; má»™t th&amp;aacute;c nÆ°á»›c hoang sÆ¡ v&amp;agrave; h&amp;ugrave;ng vÄ©.&amp;nbsp;Qu&amp;yacute; kh&amp;aacute;ch tá»± do táº¯m suá»‘i.Äo&amp;agrave;n d&amp;ugrave;ng bá»¯a trÆ°a d&amp;atilde; ngoáº¡i tr&amp;ecirc;n n&amp;uacute;i. Buá»•i chiá»u, xe Ä‘Æ°a Ä‘o&amp;agrave;n vá» láº¡i Siem Reap v&amp;agrave; tham quan mua sáº¯m táº¡i chá»£ Siem Reap.&lt;/p&gt;\r\n\r\n&lt;p&gt;&amp;nbsp;&lt;/p&gt;\r\n', '2017-04-03 09:00:00', '2017-04-06 09:00:00', 9),
('DL03', 'HN01', 'TN01', 'DL01', 'ÄÃ  Láº¡t -ThÃ nh phá»‘ hoa -Thung LÅ©ng VÃ ng-VÆ°á»n DÃ¢u TÃ¢y ', 'views/images/DL.jpg', 'ÄÃ  Láº¡t má»™ng mÆ¡ nÆ¡i mimosa vÃ  ngÃ n hoa khoe sáº¯c, tá»« Ä‘á»“i Robin ngáº¯m Há»“ Tuyá»n LÃ¢m, nÃºi Voi, viáº¿ng Thiá»n Viá»‡n TrÃºc LÃ¢m, thÄƒm Dinh Báº£o Äáº¡i, táº£n bá»™ dÆ°á»›i nhá»¯ng tÃ¡n thÃ´ng, ngáº¯m biá»‡t thá»± cá»•, nháº¥m nhÃ¡p ly cafÃ© áº¥m Ã¡p trong thá»i tiáº¿t se láº¡nh. Nhá»¯ng chuyáº¿n xe ngá»±a thá»• má»™ cháº¡y quanh Há»“ XuÃ¢n HÆ°Æ¡ng cÅ©ng lÃ  nÃ©t duyÃªn cá»§a ÄÃ  Láº¡t má» sÆ°Æ¡ng.', '5700000', '&lt;h2&gt;&lt;em&gt;Ng&amp;agrave;y 1 : H&amp;Agrave; Ná»˜I &amp;ndash; Ä&amp;Agrave; Láº T Sá»‘ bá»¯a Äƒn: 1 bá»¯a&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/DL.jpg&quot; style=&quot;height:492px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Qu&amp;yacute; kh&amp;aacute;ch táº­p trung táº¡i s&amp;acirc;n bay Ná»™i B&amp;agrave;i, hÆ°á»›ng dáº«n vi&amp;ecirc;n Ä‘&amp;oacute;n Ä‘o&amp;agrave;n v&amp;agrave; l&amp;agrave;m thá»§ tá»¥c cho Qu&amp;yacute; kh&amp;aacute;ch Ä‘&amp;aacute;p chuyáº¿n bay (Trong trÆ°á»ng há»£p chuyáº¿n bay khá»Ÿi h&amp;agrave;nh Ä‘i&amp;nbsp; Ä&amp;agrave; Láº¡t trÆ°á»›c 12h trÆ°a th&amp;igrave; Vietravel sáº½ táº·ng 1 bá»¯a trÆ°a cho qu&amp;yacute; kh&amp;aacute;ch táº¡i Ä&amp;agrave; Láº¡t) Ä‘i Ä&amp;agrave; Láº¡t. Äáº¿n s&amp;acirc;n bay Li&amp;ecirc;n KhÆ°Æ¡ng, xe v&amp;agrave; hÆ°á»›ng dáº«n vi&amp;ecirc;n Ä‘Æ°a Ä‘o&amp;agrave;n vá» kh&amp;aacute;ch sáº¡n nháº­n ph&amp;ograve;ng nghá»‰ ngÆ¡i, sau Ä‘&amp;oacute; d&amp;ugrave;ng bá»¯a tá»‘i táº¡i nh&amp;agrave; h&amp;agrave;ng. Buá»•i tá»‘i tá»± do kh&amp;aacute;m ph&amp;aacute; Ä&amp;agrave; Láº¡t vá» Ä‘&amp;ecirc;m.&amp;nbsp;Nghá»‰ Ä‘&amp;ecirc;m táº¡i Ä&amp;agrave; Láº¡t.&lt;/p&gt;\r\n\r\n&lt;h2&gt;&lt;em&gt;Ng&amp;agrave;y 2 : Ä&amp;Agrave; Láº T - CAO NGUY&amp;Ecirc;N HUYá»€N DIá»†U Sá»‘ bá»¯a Äƒn: 3 bá»¯a&lt;/em&gt;&lt;br /&gt;\r\n&lt;img alt=&quot;&quot; src=&quot;views/images/DL1.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;Buá»•i s&amp;aacute;ng, Qu&amp;yacute; kh&amp;aacute;ch tham quan v&amp;agrave; chinh phá»¥c&amp;nbsp;N&amp;uacute;i Langbiang&amp;nbsp;- N&amp;oacute;c nh&amp;agrave; T&amp;acirc;y Nguy&amp;ecirc;n, ngáº¯m to&amp;agrave;n cáº£nh n&amp;uacute;i Ä‘á»“i,&amp;nbsp;há»“ Dankia, suá»‘i V&amp;agrave;ng&amp;nbsp;vá»›i nhá»¯ng d&amp;ograve;ng s&amp;ocirc;ng uá»‘n lÆ°á»£n tá»« tr&amp;ecirc;n cao (Qu&amp;yacute; kh&amp;aacute;ch c&amp;oacute; thá»ƒ Ä‘i l&amp;ecirc;n n&amp;uacute;i báº±ng xe Jeep - Chi ph&amp;iacute; tá»± t&amp;uacute;c). Sau Ä‘&amp;oacute;, Äo&amp;agrave;n tham quan&amp;nbsp;Nh&amp;agrave; thá» Domain De Marie. Ä‚n TrÆ°a. Buá»•i chiá»u, xe Ä‘Æ°a Q&amp;uacute;y kh&amp;aacute;ch tham quan&amp;nbsp;Nh&amp;agrave; ga xe lá»­a Ä&amp;agrave; Láº¡t&amp;nbsp;- Ä&amp;acirc;y Ä‘Æ°á»£c xem l&amp;agrave; nh&amp;agrave; ga cá»• k&amp;iacute;nh nháº¥t&amp;nbsp;Viá»‡t Nam&amp;nbsp;v&amp;agrave;&amp;nbsp;Ä&amp;ocirc;ng DÆ°Æ¡ng. Hiá»‡n táº¡i c&amp;ocirc;ng tr&amp;igrave;nh kiáº¿n tr&amp;uacute;c phá»‘ n&amp;uacute;i n&amp;agrave;y váº«n giá»¯ Ä‘Æ°á»£c nguy&amp;ecirc;n váº¹n h&amp;igrave;nh d&amp;aacute;ng kiáº¿n tr&amp;uacute;c tá»« tá»•ng thá»ƒ Ä‘áº¿n tá»«ng chi tiáº¿t tá»« ng&amp;agrave;y má»›i x&amp;acirc;y dá»±ng c&amp;aacute;ch nay gáº§n 70 nÄƒm. Nh&amp;agrave; ga Ä‘Æ°á»£c ngÆ°á»i Ph&amp;aacute;p x&amp;acirc;y dá»±ng tá»« nÄƒm&amp;nbsp;1932&amp;nbsp;Ä‘áº¿n&amp;nbsp;1938&amp;nbsp;th&amp;igrave; ho&amp;agrave;n th&amp;agrave;nh, l&amp;agrave; nh&amp;agrave; ga Ä‘áº§u má»‘i tr&amp;ecirc;n tuyáº¿n&amp;nbsp;ÄÆ°á»ng sáº¯t Phan Rang-Ä&amp;agrave; Láº¡t&amp;nbsp;d&amp;agrave;i 84&amp;nbsp;km. Nh&amp;agrave; ga c&amp;oacute; phong c&amp;aacute;ch kiáº¿n tr&amp;uacute;c Ä‘á»™c Ä‘&amp;aacute;o, c&amp;oacute; ba m&amp;aacute;i h&amp;igrave;nh ch&amp;oacute;p, l&amp;agrave; c&amp;aacute;ch Ä‘iá»‡u ba Ä‘á»‰nh&amp;nbsp;n&amp;uacute;i Langbiang &amp;nbsp;v&amp;agrave; &amp;nbsp;nh&amp;agrave; r&amp;ocirc;ng&amp;nbsp;T&amp;acirc;y Nguy&amp;ecirc;n. Nh&amp;agrave; ga Ä‘&amp;atilde; Ä‘Æ°á»£c&amp;nbsp;Bá»™ VÄƒn h&amp;oacute;a - Th&amp;ocirc;ng tin&amp;nbsp;Viá»‡t&amp;nbsp;Nam&amp;nbsp;c&amp;ocirc;ng nháº­n l&amp;agrave;&amp;nbsp;di t&amp;iacute;ch lá»‹ch sá»­ vÄƒn h&amp;oacute;a quá»‘c gia v&amp;agrave; l&amp;agrave; Ä‘iá»ƒm tham quan du lá»‹ch háº¥p dáº«n cá»§a th&amp;agrave;nh phá»‘ Ä&amp;agrave; Láº¡t ng&amp;agrave;y nay. Tiáº¿p tá»¥c xe Ä‘Æ°a Qu&amp;yacute; kh&amp;aacute;ch tham quan&amp;nbsp;Ch&amp;ugrave;a Linh PhÆ°á»›c -&amp;nbsp;C&amp;ograve;n Ä‘Æ°á»£c gá»i l&amp;agrave;&amp;nbsp;Ch&amp;ugrave;a Rá»“ng&amp;nbsp;v&amp;igrave; b&amp;ecirc;n trong hoa vi&amp;ecirc;n cáº¡nh ch&amp;ugrave;a c&amp;oacute; má»™t con rá»“ng Ä‘Æ°á»£c x&amp;acirc;y dá»±ng báº±ng ve chai ráº¥t Ä‘á»™c Ä‘&amp;aacute;o. Sau Ä‘&amp;oacute;, Ä‘o&amp;agrave;n tham quan&amp;nbsp;Dinh III&amp;nbsp;- Biá»‡t thá»± nghá»‰ h&amp;egrave; cá»§a vua Báº£o Äáº¡i, vá»‹ ho&amp;agrave;ng Ä‘áº¿ cuá»‘i c&amp;ugrave;ng cá»§a triá»u Nguyá»…n Ä‘á»“ng thá»i cÅ©ng l&amp;agrave; vá»‹ ho&amp;agrave;ng Ä‘áº¿ cuá»‘i c&amp;ugrave;ng cá»§a c&amp;aacute;c triá»u Ä‘áº¡i phong kiáº¿n Viá»‡t Nam. Äo&amp;agrave;n trá»Ÿ vá» kh&amp;aacute;ch sáº¡n nghá»‰ ngÆ¡i, Äƒn tá»‘i. Nghá»‰ Ä‘&amp;ecirc;m táº¡i Ä&amp;agrave; Láº¡t.&amp;nbsp;Nghá»‰ Ä‘&amp;ecirc;m táº¡i Ä&amp;agrave; Láº¡t.&lt;/p&gt;\r\n', '2017-03-08 10:00:00', '2017-03-12 15:00:00', 9),
('DL04', 'HP01', 'NN01', 'HQ01', 'Seoul - Jeju - Naksan - Lotte World HÃ nh trÃ¬nh cÃ¹ng nhau theo dáº¥u phim Tuá»•i Thanh XuÃ¢n. ', 'views/images/HQ.jpg', 'HÃ n Quá»‘c ná»•i tiáº¿ng khÃ´ng chá»‰ vÃ¬ phong cáº£nh Ä‘áº¹p vÃ  mÃ³n Äƒn ngon, ná»n vÄƒn hÃ³a Ä‘áº·c trÆ°ng thÃ¬ cÃ²n ná»•i tiáº¿ng lÃ  nÆ¡i sáº£n xuáº¥t ra nhá»¯ng bá»™ phim Ä‘i vÃ o lÃ²ng khÃ¡n giáº£ Viá»‡t Nam cÅ©ng nhÆ° tháº¿ giá»›i. Tiáº¿p ná»‘i thÃ nh cÃ´ng cá»§a bá»™ phim â€œTuá»•i Thanh XuÃ¢nâ€ Ä‘ang lÃ m say lÃ²ng giá»›i yÃªu phim, Vietravel vÃ  KTO hÃ¢n háº¡nh giá»›i thiá»‡u Ä‘áº¿n du khÃ¡ch hÃ nh trÃ¬nh du lá»‹ch â€œtheo dáº¥uâ€ bá»™ phim nÃ y báº±ng nhá»¯ng Ä‘iá»ƒm tham quan lï', '15400000', '&lt;h2&gt;&lt;em&gt;Ng&amp;agrave;y 1 : H&amp;Agrave; Ná»˜I &amp;ndash; SEOUL (Nghá»‰ Ä‘&amp;ecirc;m tr&amp;ecirc;n m&amp;aacute;y bay)&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/HQ.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Táº­p trung 22h táº¡i sá»‘ 3 Hai B&amp;agrave; TrÆ°ng, H&amp;agrave; Ná»™i.&lt;br /&gt;\r\n&lt;br /&gt;\r\nXe v&amp;agrave; hÆ°á»›ng dáº«n vi&amp;ecirc;n Ä‘&amp;oacute;n Ä‘o&amp;agrave;n v&amp;agrave; Ä‘Æ°a ra s&amp;acirc;n bay Ná»™i B&amp;agrave;i, Ä‘&amp;aacute;p chuyáº¿n bay Ä‘i Seoul - H&amp;agrave;n Quá»‘c.&lt;br /&gt;\r\n&lt;br /&gt;\r\nTá»›i s&amp;acirc;n bay Quá»‘c táº¿ Incheon tr&amp;ecirc;n chuyáº¿n bay VJ960 HAN &amp;ndash; ICH 01:45 7:00, Qu&amp;yacute; kh&amp;aacute;ch sáº½ Ä‘Æ°á»£c hÆ°á»›ng dáº«n vi&amp;ecirc;n v&amp;agrave; xe du lá»‹ch cá»§a c&amp;ocirc;ng ty Ä‘&amp;oacute;n Ä‘o&amp;agrave;n Ä‘áº¿n vá»›i Seoul - th&amp;agrave;nh phá»‘ hiá»‡n Ä‘áº¡i v&amp;agrave; l&amp;agrave; thá»§ Ä‘&amp;ocirc; cá»§a H&amp;agrave;n Quá»‘c náº±m tráº£i d&amp;agrave;i hai b&amp;ecirc;n bá» s&amp;ocirc;ng H&amp;agrave;n hiá»n h&amp;ograve;a, &amp;ecirc;m áº£, thá»§ Ä‘&amp;ocirc; cá»§a Ä‘áº¥t nÆ°á»›c Kim Chi v&amp;agrave; báº¯t Ä‘áº§u h&amp;agrave;nh tr&amp;igrave;nh tham quan du lá»‹ch Seoul s&amp;ocirc;i Ä‘á»™ng.&amp;nbsp;&lt;/p&gt;\r\n\r\n&lt;h2&gt;ng.&amp;nbsp;&lt;br /&gt;\r\n&lt;br /&gt;\r\n&lt;em&gt;Ng&amp;agrave;y 2 : SEOUL &amp;ndash; JEJU Sá»‘ bá»¯a Äƒn: 3 bá»¯a&lt;/em&gt;&lt;/h2&gt;\r\n\r\n&lt;p&gt;&lt;em&gt;&lt;img alt=&quot;&quot; src=&quot;views/images/HQ1.jpg&quot; style=&quot;height:500px; margin-left:150px; margin-right:150px; width:700px&quot; /&gt;&lt;/em&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Xe v&amp;agrave; HDV Ä‘&amp;oacute;n Ä‘o&amp;agrave;n táº¡i s&amp;acirc;n bay. Sau Ä‘&amp;oacute;, xe sáº½ Ä‘Æ°a Ä‘o&amp;agrave;n vá» trung t&amp;acirc;m th&amp;agrave;nh phá»‘ Seoul.&lt;br /&gt;\r\n&lt;br /&gt;\r\nQu&amp;yacute; kh&amp;aacute;ch sáº½ tham quan cung Ä‘iá»‡n Gyeongbok - Ä&amp;acirc;y l&amp;agrave; nÆ¡i á»Ÿ ch&amp;iacute;nh cá»§a Ho&amp;agrave;ng gia trong suá»‘t vÆ°Æ¡ng triá»u Chosun (1392-1910).Cung Ä‘iá»‡n n&amp;agrave;y c&amp;oacute; 7225 ph&amp;ograve;ng vá»›i thiáº¿t triá»u nguy nga, nhá»¯ng sáº£nh Ä‘Æ°á»ng tao nh&amp;atilde;. Äiá»‡n Gyeongbok Ä‘Æ°á»£c coi l&amp;agrave; c&amp;ocirc;ng tr&amp;igrave;nh nghá»‡ thuáº­t ná»•i tiáº¿ng c&amp;oacute; phong c&amp;aacute;ch v&amp;agrave; kiáº¿n tr&amp;uacute;c Ä‘á»™c Ä‘&amp;aacute;o v&amp;agrave; Ä‘áº¹p nháº¥t Seoul.&lt;br /&gt;\r\n&lt;br /&gt;\r\nSau Ä‘&amp;oacute; hÆ°á»›ng dáº«n vi&amp;ecirc;n v&amp;agrave; xe du lá»‹ch cá»§a c&amp;ocirc;ng ty Ä‘&amp;oacute;n qu&amp;yacute; kh&amp;aacute;ch ra s&amp;acirc;n bay Gimpo Ä‘i Äáº£o Jeju - h&amp;ograve;n Ä‘áº£o xinh Ä‘áº¹p vá»›i phong cáº£nh thanh b&amp;igrave;nh, bá» biá»ƒn tr&amp;agrave;n ngáº­p náº¯ng v&amp;agrave; gi&amp;oacute;. Qu&amp;yacute; kh&amp;aacute;ch sáº½ Ä‘i tr&amp;ecirc;n chuyáº¿n bay Ä‘i JejuGMP - CJU.&lt;br /&gt;\r\n&lt;br /&gt;\r\nTá»›i nÆ¡i Qu&amp;yacute; kh&amp;aacute;ch tham quan con Ä‘Æ°á»ng Ká»³ B&amp;iacute; (Mysterious Road) &amp;ndash; Má»™t nÆ¡i b&amp;iacute; áº©n nháº¥t h&amp;agrave;nh tinh m&amp;agrave; Ä‘áº¿n nay khoa há»c hiá»‡n Ä‘áº¡i cÅ©ng váº«n chÆ°a thá»ƒ l&amp;yacute; giáº£i ná»•i, C&amp;ocirc;ng vi&amp;ecirc;n Thi&amp;ecirc;n Ä‘Æ°á»ng t&amp;igrave;nh y&amp;ecirc;u &amp;ldquo;Loveland&amp;rdquo; &amp;ndash; tháº¿ giá»›i ri&amp;ecirc;ng tÆ° cá»§a nhá»¯ng cáº·p t&amp;igrave;nh nh&amp;acirc;n háº¡nh ph&amp;uacute;c (cáº¥m tráº» em dÆ°á»›i 18 tuá»•i).&lt;br /&gt;\r\n&lt;br /&gt;\r\nNghá»‰ Ä‘&amp;ecirc;m táº¡i kh&amp;aacute;ch sáº¡n á»Ÿ Ä‘áº£o Jeju.&lt;/p&gt;\r\n', '2017-03-12 00:00:00', '2017-03-15 00:00:00', 7);

-- --------------------------------------------------------

--
-- Table structure for table `ykienkhachhang`
--

CREATE TABLE `ykienkhachhang` (
  `MaYKien` int(10) NOT NULL,
  `Email` varchar(20) NOT NULL,
  `HoTen` varchar(30) NOT NULL,
  `NoiDung` varchar(4000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ykienkhachhang`
--

INSERT INTO `ykienkhachhang` (`MaYKien`, `Email`, `HoTen`, `NoiDung`) VALUES
(0, 'bach@gmail.com', 'phu', 'Ráº¥t vui');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`User`);

--
-- Indexes for table `chitietdat`
--
ALTER TABLE `chitietdat`
  ADD KEY `MaTour` (`MaTour`),
  ADD KEY `MaDat` (`MaDat`);

--
-- Indexes for table `dattour`
--
ALTER TABLE `dattour`
  ADD PRIMARY KEY (`MaDat`),
  ADD KEY `MaTV` (`MaTV`);

--
-- Indexes for table `diemden`
--
ALTER TABLE `diemden`
  ADD PRIMARY KEY (`MaDD`),
  ADD KEY `MaLoai` (`MaLoai`);
ALTER TABLE `diemden` ADD FULLTEXT KEY `index_TenDD` (`TenDD`);
ALTER TABLE `diemden` ADD FULLTEXT KEY `TenDD_2` (`TenDD`);
ALTER TABLE `diemden` ADD FULLTEXT KEY `TenDD_3` (`TenDD`);
ALTER TABLE `diemden` ADD FULLTEXT KEY `TenDD` (`TenDD`);

--
-- Indexes for table `diemkh`
--
ALTER TABLE `diemkh`
  ADD PRIMARY KEY (`MaKH`);

--
-- Indexes for table `loaitour`
--
ALTER TABLE `loaitour`
  ADD PRIMARY KEY (`MaLoai`);

--
-- Indexes for table `thanhvien`
--
ALTER TABLE `thanhvien`
  ADD PRIMARY KEY (`MaTV`);

--
-- Indexes for table `tintuc`
--
ALTER TABLE `tintuc`
  ADD PRIMARY KEY (`MaTin`);

--
-- Indexes for table `ttour`
--
ALTER TABLE `ttour`
  ADD PRIMARY KEY (`MaTour`),
  ADD KEY `MaKH` (`MaKH`),
  ADD KEY `MaLoai` (`MaLoai`),
  ADD KEY `MaDD` (`MaDD`);

--
-- Indexes for table `ykienkhachhang`
--
ALTER TABLE `ykienkhachhang`
  ADD PRIMARY KEY (`MaYKien`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dattour`
--
ALTER TABLE `dattour`
  MODIFY `MaDat` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `thanhvien`
--
ALTER TABLE `thanhvien`
  MODIFY `MaTV` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `chitietdat`
--
ALTER TABLE `chitietdat`
  ADD CONSTRAINT `chitietdat_ibfk_1` FOREIGN KEY (`MaTour`) REFERENCES `ttour` (`MaTour`),
  ADD CONSTRAINT `chitietdat_ibfk_2` FOREIGN KEY (`MaDat`) REFERENCES `dattour` (`MaDat`);

--
-- Constraints for table `dattour`
--
ALTER TABLE `dattour`
  ADD CONSTRAINT `dattour_ibfk_1` FOREIGN KEY (`MaTV`) REFERENCES `thanhvien` (`MaTV`);

--
-- Constraints for table `diemden`
--
ALTER TABLE `diemden`
  ADD CONSTRAINT `diemden_ibfk_1` FOREIGN KEY (`MaLoai`) REFERENCES `loaitour` (`MaLoai`);

--
-- Constraints for table `ttour`
--
ALTER TABLE `ttour`
  ADD CONSTRAINT `ttour_ibfk_1` FOREIGN KEY (`MaKH`) REFERENCES `diemkh` (`MaKH`),
  ADD CONSTRAINT `ttour_ibfk_2` FOREIGN KEY (`MaLoai`) REFERENCES `loaitour` (`MaLoai`),
  ADD CONSTRAINT `ttour_ibfk_3` FOREIGN KEY (`MaDD`) REFERENCES `diemden` (`MaDD`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
