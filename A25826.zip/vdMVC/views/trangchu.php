  <!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
    <script src="views/bootstrap/js/jquery.js"></script>
    <script src="views/bootstrap/js/bootstrap.min.js"></script>
    <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
    <title></title>
  </head>
  <body>
    <?php if(!isset($_SESSION['User'])) { ?>
    <form class="" action="" method="post">
      <div id="head" class="container form-horizontal" role="form">
        <div class="form-inline taikhoan">
          <input type="text" name="User" value="" class="hello form-control" size="10px" placeholder="Tên đăng nhập">
          <input type="password" name="Password" value="" class="hello form-control" size="10px" placeholder="Password">
          <input type="submit" name="action" value="Login" class="hello btn btn-primary" size="10px">
          <a href="index.php?controller=thongtin&action=Forgot" class="hello" style="">Forgot password</a> | <a href="index.php?controller=dangky&action=insert">Registration</a>
        </div>
      </div>
    </form>
    <?php } else { ?>
      <form class="" action="" method="post">
        <div id="head" class="container">
            <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào <?php echo $_SESSION['User']; ?> </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
        </div>
      </form>
      <?php } ?>
    <nav class="navbar navbar-inverse" role="navigation">
      <h2 class="nav navbar-nav text-primary" style="margin-top:7px; margin-left:30px"><i>Travel Anywhere</i></h2>
            <div class="container-fluid" style="margin-left:500px">
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php?controller=trangchu">Home</a>
                </div>
                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li>
                            <a class="" href="index.php?controller=tintuc">Tin Tức</a>
                        </li>
                        <li>
                            <a href="index.php?controller=dattour">Đặt Tour</a>
                        </li>
                        <li>
                            <a href="index.php?controller=ykien">Ý Kiến Khách Hàng</a>
                        </li>
                        <li>
                            <a href="index.php?controller=lienhe">Liên Hệ</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <header id="myCarousel" class="carousel slide">
        <!-- Indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
        <div class="carousel-inner">
          <?php foreach ($t as $key => $tt){ if($key==0) {?>
            <div class="item active">
              <a href="index.php?controller=tintuc&action=view&MaTin=<?php echo $tt->MaTin ?>"><img src="<?php echo $tt->Anh; ?>" style="height:400px; width:1300px" alt=""></a>
              <div class="carousel-caption">
                  <h2 class="text-warning" style="text-shadow: 3px 3px 0px rgba(0,0,0,.3), -5px -5px 8px rgba(255,0,255,.7);color: rgb(139, 3, 147);"><i><?php echo $tt->TenTin; ?></i></h2>
              </div>
            </div>
              <?php }else{ ?>
            <div class="item">
            <a href="index.php?controller=tintuc&action=view&MaTin=<?php echo $tt->MaTin ?>"><img src="<?php echo $tt->Anh; ?>" style="height:400px; width:1300px" alt=""></a>
              <div class="carousel-caption">
                  <h2 class="text-warning" style="text-shadow: 3px 3px 0px rgba(0,0,0,.3), -5px -5px 8px rgba(255,0,255,.7);color: rgb(139, 3, 147);"><i><?php echo $tt->TenTin; ?></i></h2>
              </div>
            </div>
          <?php }} ?>
        </div>
        <a class="left carousel-control" href="#myCarousel" data-slide="prev">
            <span class="icon-prev"></span>
        </a>
        <a class="right carousel-control" href="#myCarousel" data-slide="next">
            <span class="icon-next"></span>
        </a>
    </header>
    <script>
    $('.carousel').carousel({
        interval: 5000
    })
    </script>
    <div class="container">
        <hr>
        <div class="row">
            <div class="col-sm-8">
                <h2>VIETRAVEL</h2>
              <p>Trên cơ sở phát triển bền vững sau gần 20 năm hình thành và phát triển, Vietravel hướng đến trở thành 1 trong 10 công ty lữ hành hàng đầu khu vực Đông Nam Á vào năm 2015. Đến năm 2020. Vietravel phấn đấu trở thành 1 trong 10 công ty du lịch hàng đầu châu Á và trở thành Top Tập đoàn lữ hành hàng đầu khu vực Châu Á. Đây là tầm nhìn chiến lược và đầy thử thách nhưng với một mục tiêu chung, Vietravel đã và đang hiện thực hoá những mục tiêu chiến lược của mình</p>
            </div>
            <div class="col-sm-4">
                <h2>Tìm Kiếm</h2>
                <br>
                <form class="" action="" method="post">
                  <input type="text" name="TenDiem" value="" class="form-control" placeholder="Nhập tên điểm đến">
                  <input type="submit" name="action" value="Tìm Kiếm" class="btn btn-primary" style="margin-top:20px">
                </form>
            </div>
        </div>
        <div class="row" style="margin-top:100px">
          <?php foreach($tour as $key => $tour) {?>
            <div class="col-sm-4">
               <img class="img-rounded img-responsive img-center" src="<?php echo $tour->Anh; ?>" alt="" style="width:300px;height:200px">
               <h2><?php echo $tour->TenTour; ?></h2>
               <p><?php echo $tour->GTTour; ?></p>
               <a class="btn btn-primary" href="index.php?controller=dattour&action=view&MaTour=<?php echo $tour->MaTour; ?>">Đặt Tour</a>
           </div>
          <?php } ?>
        </div>
        <hr>
        <footer>
            <div class="row">
                <div class="col-lg-12">
                    <p>Địa chỉ : Hai Bà Trưng, Hà Nội</p>
                </div>
            </div>
        </footer>
  </body>
</html>
