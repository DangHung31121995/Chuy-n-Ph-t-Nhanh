<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
    <script src="views/bootstrap/js/bootstrap.min.js"></script>
    <script src="views/bootstrap/js/jquery-3.1.1.min.js"></script>
    <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
    <title></title>
  </head>
  <body>
    <form class="" action="" method="post">
      <div id="head" class="container">
          <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào <?php echo $_SESSION['User']; ?> </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
      </div>
    </form>
    <div class="container row">
       <div class="col-xs-6 col-md-4 ql page-header">
         <div class="ql1">
           <a href="index.php?controller=trangchu" class="btn btn-primary  ql2" role="button">Trang chủ</a>
         </div>
         <div class="ql1">
           <a href="index.php?controller=thongtin" class="btn btn-primary  ql2" role="button">Thông tin cá nhân</a>
         </div>
         <div class="ql1">
           <a href="index.php?controller=thongtin&action=pass" class="btn btn-primary  ql2" role="button">Đổi Mật Khẩu</a>
         </div>
       </div>
         <div class="col-xs-12 col-md-8">
             <h1 class="page-header">
                 <small><i>Đổi Mật Khẩu</i></small>
             </h1>
             <form class="" action="" method="post" style="margin-left:80px">
                 <label for="Pas">Mật khẩu mới<input class="form-control i1" type="password" id="Pas" name="Pas" value=""></label>
                 <label for="Pas1">Nhập lại mật khẩu mới<input class="form-control i1" type="password" id="Pas1" name="Pas1" value=""></label>
                 <div class="Up" style="margin-left:200px">
                   <input class="btn btn-primary" type="submit" name="action" value="Thay đổi">
                   <a href="index.php?controller=thongtin" class="btn btn-primary a2">Hủy</a>
                 </div>
             </form>
         </div>
     </div>
</body>
</html>
