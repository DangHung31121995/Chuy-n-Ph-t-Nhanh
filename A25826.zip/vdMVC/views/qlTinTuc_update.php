<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/ckeditor/ckeditor.js"></script>
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css" />
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="#">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he1">
      <form class="" action="" method="POST" enctype="multipart/form-data">
        <label for="MaTin" class="control-label">Mã Tin</label>
        <input class="form-control i1" type="text" id="MaTin" name="MaTin" value="<?php echo $qlTinTuc->MaTin ?>">
        <label for="TenTin" class="u control-label">Tên Tiêu Đề
        <input class="form-control i1" type="text" id="TenTin" name="TenTin" value="<?php echo $qlTinTuc->TenTin ?>"></label>
        <label for="AnhT" class="u control-label">Ảnh
        <input class="form-control i1" type="file" id="AnhT" name="AnhT" value="<?php echo $qlTinTuc->Anh; ?>"></label>
        <label for="NDTomTat" class="u control-label">Giới Thiệu
        <textarea class="form-control i1" name="NDTomTat" rows="3"><?php echo $qlTinTuc->NDTomTat; ?></textarea></label>
        <label for="Ten">Nội Dung<textarea id="Ten" name="Ten" cols="80" rows="3"><?php echo html_entity_decode($qlTinTuc->NoiDung, ENT_QUOTES, 'UTF-8'); ?></textarea>
        <script>CKEDITOR.replace( 'Ten' );</script>
        <label for="NgayGui" class="control-label">Ngày Gửi</label>
        <input class="form-control i1" type="datetime" id="NgayGui" name="NgayGui" value="<?php echo $qlTinTuc->NgayGui; ?>">
        <div class="Up">
          <input type="submit" name="action" value="UpDate" class="btn btn-primary">
          <a href="index.php?controller=qlTinTuc" class="btn btn-primary a2">Can</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>
