<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css" />
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="#">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he1">
      <form class="" action="" method="POST">
        <label for="MaDD">Mã điểm đến : <input class="form-control i1" type="text" id="MaDD" name="MaDD" value="<?php echo $qlDiemDen->MaDD ?>"></label>
        <label for="MaLoai">Mã loại tour : <select class="form-control i1" id="MaLoai" name="MaLoai">
          <?php foreach($data as $key=>$LT) { if($LT->MaLoai==$qlDiemDen->MaLoai){ ?>
              <option value="<?php echo $LT->MaLoai; ?>" selected="selected"><?php echo $LT->MaLoai; ?></option>
          <?php }else{ ?>
              <option value="<?php echo $LT->MaLoai; ?>"><?php echo $LT->MaLoai; ?></option>
          <?php }} ?>
        </select></label>
        <label for="TenDD">Tên điểm đến : <input class="form-control i1" type="text" id="TenDD" name="TenDD" value="<?php echo $qlDiemDen->TenDD ?>"></label>
        <div class="Up">
          <input class="btn btn-primary" type="submit" name="action" value="UpDate">
          <a href="index.php?controller=qlDiemKH" class="btn btn-primary a2">Can</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>
