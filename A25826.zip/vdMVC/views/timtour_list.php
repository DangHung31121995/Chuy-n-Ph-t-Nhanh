<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/jquery-3.1.1.min.js"></script>
  <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
  <title></title>
</head>
<body>
  <?php if(!isset($_SESSION['User'])) { ?>
  <form class="" action="" method="post">
    <div id="head" class="container form-horizontal" role="form">
      <div class="form-inline taikhoan">
        <input type="text" name="User" value="" class="hello form-control" size="10px" placeholder="Tên đăng nhập">
        <input type="password" name="Password" value="" class="hello form-control" size="10px" placeholder="Password">
        <input type="submit" name="action" value="Login" class="hello btn btn-primary" size="10px">
        <a href="index.php?controller=thongtin&action=Forgot" class="hello" style="">Forgot password</a> | <a href="index.php?controller=dangky&action=insert">Registration</a>
      </div>
    </div>
  </form>
  <?php } else { ?>
    <form class="" action="" method="post">
      <div id="head" class="container">
          <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào <?php echo $_SESSION['User']; ?> </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
      </div>
    </form>
    <?php } ?>
  <nav class="navbar navbar-inverse" role="navigation">
    <h2 class="nav navbar-nav text-primary" style="margin-top:7px; margin-left:30px"><i>Travel Anywhere</i></h2>
          <div class="container-fluid" style="margin-left:500px">
              <div class="navbar-header">
                  <a class="navbar-brand" href="index.php?controller=trangchu">Home</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                      <li>
                          <a href="index.php?controller=tintuc">Tin Tức</a>
                      </li>
                      <li>
                          <a href="index.php?controller=dattour ">Đặt Tour</a>
                      </li>
                      <li>
                          <a href="index.php?controller=ykien">Ý Kiến Khách Hàng</a>
                      </li>
                      <li>
                          <a href="index.php?controller=lienhe">Liên Hệ</a>
                      </li>
                  </ul>
              </div>
          </div>
      </nav>
      <div class="container">
       <div class="row">
           <div class="col-lg-12">
               <h1 class="page-header">
                   <small><i>Danh sách tour du lịch</i></small>
               </h1>
           </div>
       </div>
    </div>
    <?php if(!$t){ ?>
      <h2 class="text-center"><i>Tour du lịch bạn nhập không đúng</i></h2>
    <?php }else{?>
    <table class="table table-hover text-center">
      <tr>
        <td>Mã Tour</td>
        <td>Điểm Đến</td>
        <td>Ngày Đi</td>
        <td>Ngày Về</td>
        <td>Giá</td>
        <td>Chỗ Còn Nhận</td>
      </tr>
      <?php foreach($t as $key=>$tt){ ?>
        <tr>
          <td><?php echo $tt->MaTour; ?></td>
          <td><?php echo $tt->TenDD; ?></td>
          <td><?php echo $tt->NgayKhoiHanh; ?></td>
          <td><?php echo $tt->NgayVe; ?></td>
          <td><?php echo $tt->GiaTour; ?></td>
          <td><?php echo $tt->SoCho; ?></td>
          <td><a class="btn btn-primary" href="index.php?controller=dattour&action=view&MaTour=<?php echo $tt->MaTour ?>">Đặt Tour</a></td>
        </tr>
        <?php }}?>
    </table>
</body>
</html>
