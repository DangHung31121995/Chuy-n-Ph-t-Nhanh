<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/ckeditor/ckeditor.js"></script>
  <script type="text/javascript" src="views/bootstrap/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css"/>
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="#">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary   ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary   ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary   ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary   ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary   ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary   ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary   ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary   ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he1">
      <form class="" action="" method="POST" enctype="multipart/form-data">
        <label for="MaTin">Mã tin<input class="form-control i1" type="text" id="MaTin" name="MaTin" value=""></label>
        <label for="TenTin">Tiêu đề <input class="form-control i1" type="text" id="TenTin" name="TenTin" value=""></label>
        <label for="AnhT">Chọn Ảnh</label>
        <input type="file" name="AnhT" value="">
        <label for="NDTomTat">Giới thiệu<textarea name="NDTomTat" class="form-control i1" rows="3"></textarea></label>
        <label for="Ten">Nội Dung<textarea id="Ten" name="Ten" cols="80" rows="3"></textarea>
        <script>CKEDITOR.replace( 'Ten' );</script>
        <label for="NgayGui">Ngày Gửi<input class="form-control i1" type="datetime" name="NgayGui" id="NgayGui" value=""></label>
        <div class="Up">
          <input class="btn btn-primary" type="submit" name="action" value="Thêm Mới">
        </div>
      </form>
    </div>
  </div>
</body>
</html>
