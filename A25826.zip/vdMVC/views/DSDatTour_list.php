<!DOCTYPE html>
<?php session_start();?>
<?php
  if(!isset($_SESSION['Status']))
  {
    echo "<script>alert('Bạn chưa đăng nhập hoặc không đủ quyền đăng nhập');";
    echo "history.back(-1);</script>";
  }
 ?>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css"/>
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary   ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary   ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary   ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary   ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary   ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary   ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary   ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary   ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he">
      <form class="lb11" action="" method="post">
        <div class="text-left">
          <label for="">Danh sách khách đặt tour </label>
        </div>
      </form>
      <table class="table table-bordered text-center container">
        <tr>
          <td>Tài Khoản</td>
          <td>Số Điện thoại</td>
          <td>Email</td>
          <td>Ngày Đặt</td>
          <td>Mã Tour</td>
          <td>Ngày Về</td>
          <td>Giá</td>
          <td colspan="1">Chức Năng</td>
        </tr>
        <?php foreach($data as $key=>$ds) { ?>
          <tr>
            <td><?php echo $ds->User; ?></td>
            <td><?php echo $ds->SoDT;?></td>
            <td><?php echo $ds->Email;?></td>
            <td><?php $a=strtotime($ds->NgayDat);echo date('d/m/Y',$a); ?></td>
            <td><?php echo $ds->MaTour; ?></td>
            <td><?php echo $ds->NgayKhoiHanh; ?></td>
            <td><?php echo number_format($ds->GiaTour).'VNĐ'; ?></td>
            <td><button class="btn btn-primary a2" onclick="myFunction()">Delete</button></td>
          </tr>
          <?php } ?>
      </table>
    </div>
  </div>
  <script>
  function myFunction() {
      var r = confirm("Bạn muốn xóa?");
      if (r == true) {
          window.location.href="index.php?controller=DSDatTour&action=delete&MaDat=<?php echo $ds->MaDat;?>";
      }
  }
  </script>
</body>
</html>
