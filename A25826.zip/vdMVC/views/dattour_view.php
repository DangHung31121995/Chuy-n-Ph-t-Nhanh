<!DOCTYPE html>
<?php session_start();?>
<?php
  if(!isset($_SESSION['User']))
  {
    echo "<script>alert('Bạn chưa đăng nhập');";
    echo "history.back(-1);</script>";
  }
  ?>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/jquery-3.1.1.min.js"></script>
  <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào <?php echo $_SESSION['User']; ?> </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <nav class="navbar navbar-inverse" role="navigation">
    <h2 class="nav navbar-nav text-primary" style="margin-top:7px; margin-left:30px"><i>Travel Anywhere</i></h2>
          <div class="container-fluid" style="margin-left:500px">
              <div class="navbar-header">
                  <a class="navbar-brand" href="index.php?controller=trangchu">Home</a>
              </div>
              <!-- Collect the nav links, forms, and other content for toggling -->
              <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                  <ul class="nav navbar-nav">
                      <li>
                          <a href="index.php?controller=tintuc">Tin Tức</a>
                      </li>
                      <li>
                          <a href="index.php?controller=dattour ">Đặt Tour</a>
                      </li>
                      <li>
                          <a href="index.php?controller=ykien">Ý Kiến Khách Hàng</a>
                      </li>
                      <li>
                          <a href="index.php?controller=lienhe">Liên Hệ</a>
                      </li>
                  </ul>
              </div>
          </div>
      </nav>
      <div class="container">
       <div class="row">
           <div class="col-lg-12">
               <h1 class="page-header">
                   <small><i>Thông tin tour du lịch</i></small>
               </h1>
           </div>
       </div>
    </div>
    <h2><?php echo $tt->TenTour; ?></h2>
    <?php echo html_entity_decode($tt->NoiDung, ENT_QUOTES, 'UTF-8'); ?>
    <div class="container-fluid" style="margin-left:180px">
      <h4><i>Điểm Khởi Hành : <?php echo $tt->TenDiem; ?> <span style="margin-left:140px;">Điểm Đến : <?php echo $tt->TenDD; ?></span></i></h4>
      <h4><i>Ngày đi : <?php echo $tt->NgayKhoiHanh; ?><span style="margin-left:100px;">Ngày Về : <?php echo $tt->NgayVe; ?></span></i></h4>
      <h4><i>Giá Tour : <?php echo $tt->GiaTour; ?><span style="margin-left:185px;">Chỗ Còn Nhận : <?php echo $tt->SoCho; ?></span></i></h4>
      <div class="Up">
        <form class="" action="" method="post">
          <input type="text" name="MaTour" value="<?php echo $tt->MaTour; ?>" class="hidden">
          <input type="text" name="UserName" value="<?php echo $_SESSION['User']; ?>" class="hidden">
          <input class="btn btn-primary" type="submit" name="action" value="Đặt Tour">
          <a href="index.php?controller=dattour" class="btn btn-primary a2">Hủy</a>
        </form>
      </div>
    </div>
</body>
</html>
