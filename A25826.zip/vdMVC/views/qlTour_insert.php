<!DOCTYPE html>
<?php session_start();
  if(!isset($_SESSION['Status']))
  {
    echo "<script>alert('Bạn không đủ quyền đăng nhập');";
    echo "history.back(-1);</script>";
  }
 ?>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/ckeditor/ckeditor.js"></script>
  <script src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css" />
  <script type="text/javascript">
  function getMaDD(val) {
        $.ajax({
        type: "POST",
        url: "models/getMaDD.php",
        data:'MaLoai='+val,
        success: function(data){
          $("#Ma-list").html(data);
        }
        });
        }
  </script>
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="#">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary  ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary  ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary  ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary  ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary  ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary  ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary  ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary  ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he1">
      <form class="" action="" method="POST" enctype="multipart/form-data">
        <label for="MaTour">Mã Tour<input class="form-control i1" type="text" id="MaTour" name="MaTour" value=""></label>
        <label for="MaKH">Điểm KH <select class="form-control i1" name="MaKH">
          <?php foreach($MaKH as $key=>$DiemKH) { ?>
            <option value="<?php echo $DiemKH->MaKH ?>"><?php echo $DiemKH->TenDiem; ?></option>
            <?php } ?>
        </select></label>
        <label for="MaLoai">Loại Tour <select class="form-control i1" name="MaLoai" onChange="getMaDD(this.value);">
          <option value="">-Chọn Loại-</option>
          <?php foreach($MaLoai as $key=>$DiemKH) { ?>
            <option value="<?php echo $DiemKH->MaLoai ?>"><?php echo $DiemKH->TenLoai; ?></option>
            <?php } ?>
        </select></label>
        <label for="MaDD">Điểm Đến<select class="form-control i1" name="MaDD" id="Ma-list">
        </select></label>
        <label for="TenTour">Tên Tour<input class="form-control i1" type="text" id="TenTour" name="TenTour" value=""></label>
        <label for="AnhT">Ảnh Đại Diện <input type="file" name="AnhT" value=""></label>
        <label for="GTTour">Giới Thiệu Tour<input class="form-control i1" type="text" id="GTTour" name="GTTour" value=""></label>
        <label for="GiaTour">Giá<input class="form-control i1" type="text" id="GiaTour" name="GiaTour" value=""></label>
        <label for="Ten">Nội Dung<textarea id="Ten" name="Ten" cols="80" rows="3"></textarea>
        <script>CKEDITOR.replace( 'Ten' );</script>
        <label for="NgayKhoiHanh">Ngày Khởi Hành<input class="form-control i1" type="datetime" id="NgayKhoiHanh" name="NgayKhoiHanh" value=""></label>
        <label for="NgayVe">Ngày Về<input class="form-control i1" type="datetime" id="NgayVe" name="NgayVe" value=""></label>
        <label for="SoCho">Số Lượng<input class="form-control i1" type="text" id="SoCho" name="SoCho" value=""></label>
        <div class="Up">
          <input class="btn btn-primary" type="submit" name="action" value="Thêm Mới">
        </div>
      </form>
    </div>
  </div>
</body>
</html>
