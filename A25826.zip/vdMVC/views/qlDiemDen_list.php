<!DOCTYPE html>
<?php session_start();?>
<?php
  if(!isset($_SESSION['Status']))
  {
    echo "<script>alert('Bạn chưa đăng nhập hoặc không đủ quyền đăng nhập');";
    echo "history.back(-1);</script>";
  }
 ?>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
  <script src="views/bootstrap/js/bootstrap.min.js"></script>
  <script src="views/bootstrap/js/bootstrap.js"></script>
  <link rel="stylesheet" type="text/css" href="views/style.css" />
  <title></title>
</head>
<body>
  <form class="" action="" method="post">
    <div id="head" class="container">
        <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào admin  </b><a href="#">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
    </div>
  </form>
  <div class="container row">
    <div class="col-xs-6 col-md-4 ql">
      <div class="ql1">
        <a href="index.php?controller=qlLoaiTour" class="btn btn-primary  ql2" role="button">QuảnLýLoạiTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemKH" class="btn btn-primary  ql2" role="button">QuảnLýDiểmKhởiHành</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlDiemDen" class="btn btn-primary  ql2" role="button">QuảnLýDiểmĐến</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTinTuc" class="btn btn-primary  ql2" role="button">QuảnLýTinTức</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlTour" class="btn btn-primary  ql2" role="button">QuảnLýTour</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlThanhVien" class="btn btn-primary  ql2" role="button">QuảnLýThànhViên</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=qlYKienKH" class="btn btn-primary  ql2" role="button">ÝKiếnKháchHàng</a>
      </div>
      <div class="ql1">
        <a href="index.php?controller=DSDatTour" class="btn btn-primary  ql2" role="button">DanhSáchĐặtTour</a>
      </div>
    </div>
    <div class="col-xs-12 col-md-8 he">
      <form class="lb11" action="">
        <div class="text-left">
          <label for="">Danh sách điểm Đến </label>
          <a href="index.php?controller=qlDiemDen&action=insert" class="btn btn-primary btn- glyphicon glyphicon-plus">ThêmMới</a>
        </div>
      </form>
      <table class="table table-bordered text-center">
        <tr>
          <td>Mã Điểm Đến</td>
          <td>Mã Loại</td>
          <td>Tên Điểm Đến</td>
          <td colspan="2">Chức Năng</td>
        </tr>
        <?php foreach($data as $key=>$qlDiemDen) { ?>
          <tr>
            <td><?php echo $qlDiemDen->MaDD; ?></td>
            <td><?php echo $qlDiemDen->MaLoai; ?></td>
            <td><?php echo $qlDiemDen->TenDD;?></td>
            <td><a class="btn btn-primary glyphicon glyphicon-wrench" href="index.php?controller=qlDiemDen&action=update&MaDD=<?php echo $qlDiemDen->MaDD; ?>"><span class="sp">Update</span></a></td>
            <td><button class="btn btn-primary glyphicon glyphicon-remove" onclick="myFunction()"><span class="sp">Delete</span></button></td>
          </tr>
          <?php } ?>
      </table>
    </div>
  </div>
  <script>
  function myFunction() {
      var r = confirm("Bạn muốn xóa?");
      if (r == true) {
          window.location.href="index.php?controller=qlDiemDen&action=delete&MaDD=<?php echo $qlDiemDen->MaDD; ?>";
      }
  }
  </script>
</body>
</html>
