<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
    <script src="views/bootstrap/js/bootstrap.min.js"></script>
    <script src="views/bootstrap/js/jquery-3.1.1.min.js"></script>
    <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
    <title></title>
  </head>
  <body>
    <div class="container">
     <div class="row">
         <div class="col-lg-12">
             <h1 class="page-header">
                 <small><i>Quên mật khẩu</i></small>
             </h1>
         </div>
     </div>
  </body>
  <form class="" action="" method="post">
      <label for="User">Tên Đăng Nhập <input class="form-control i1" type="text" id="User" name="User" value=""></label>
      <label for="Email">Email <input class="form-control i1" type="email" id="Email" name="Email" value=""></label>
      <label for="SoDT">Số Điện Thoại <input class="form-control i1" type="text" id="SoDT" name="SoDT" value=""></label>
      <div class="Up" style="margin-left:200px">
        <input class="btn btn-primary" type="submit" name="action" value="Lấy lại">
        <a href="index.php?controller=trangchu" class="btn btn-primary a2">Hủy</a>
      </div>
  </form>
</html>
