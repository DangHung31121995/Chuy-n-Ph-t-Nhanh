<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="views/bootstrap/css/bootstrap-theme.min.css">
    <script src="views/bootstrap/js/bootstrap.min.js"></script>
    <script src="views/bootstrap/js/jquery-3.1.1.min.js"></script>
    <link href="views/style.css" rel="stylesheet" type="text/css" media="all" />
    <title></title>
  </head>
  <body>
    <form class="" action="" method="post">
      <div id="head" class="container">
          <p style="margin-left:600px;margin-top:5px;"class="text-center"><b>Xin chào <?php echo $_SESSION['User']; ?> </b><a href="index.php?controller=thongtin">PassWord</a>|<a href="index.php?controller=trangchu&action=logout">LogOut</a></p>
      </div>
    </form>
    <div class="container row">
       <div class="col-xs-6 col-md-4 ql page-header">
         <div class="ql1">
           <a href="index.php?controller=trangchu" class="btn btn-primary  ql2" role="button">Trang chủ</a>
         </div>
         <div class="ql1">
           <a href="index.php?controller=thongtin" class="btn btn-primary  ql2" role="button">Thông tin cá nhân</a>
         </div>
         <div class="ql1">
           <a href="index.php?controller=thongtin&action=pass" class="btn btn-primary  ql2" role="button">Đổi Mật Khẩu</a>
         </div>
       </div>
         <div class="col-xs-12 col-md-8">
             <h1 class="page-header">
                 <small><i>Thông tin cá nhân</i></small>
             </h1>
             <form class="" action="" method="post" style="margin-left:80px" onsubmit="return confirm('Bạn muốn cập nhật lại thông tin ?');">
                 <label for="HoTen">Họ Và Tên <input class="form-control i1" type="text" id="HoTen" name="HoTen" value="<?php echo $data->HoTen; ?>"></label>
                 <label for="GioiTinh">Giới Tính<br>
                   <div style="margin-left:100px">
                     <?php if($data->GioiTinh=='Nam'){?>
                       <input type="radio" name="GioiTinh" id="GioiTinh" value="Nam" checked>Nam
                       <input type="radio" name="GioiTinh" id="GioiTinh" value="Nữ" style="margin-left:50px">Nữ
                     <?php }else{ ?>
                       <input type="radio" name="GioiTinh" id="GioiTinh" value="Nam">Nam
                       <input type="radio" name="GioiTinh" id="GioiTinh" value="Nữ" style="margin-left:50px" checked>Nữ
                       <?php } ?>
                   </div>
                 </label>
                 <label for="DiaChi">Địa Chỉ<input class="form-control i1" type="text" id="DiaChi" name="DiaChi" value="<?php echo $data->DiaChi ?>"></label>
                 <label for="SoCMT">Số Chứng Minh Thư <input disabled class="form-control i1" type="text" id="SoCMT" name="SoCMT" value=<?php echo $data->SoCMT; ?>></label>
                 <label for="Email">Email <input disabled class="form-control i1" type="email" id="Email" name="Email" value="<?php echo $data->Email; ?>"></label>
                 <label for="SoDT">Số Điện Thoại <input disabled class="form-control i1" type="text" id="SoDT" name="SoDT" value="<?php echo $data->SoDT; ?>"></label>
                 <div class="Up" style="margin-left:200px">
                   <input class="btn btn-primary" type="submit" name="action" value="Cập nhật">
                 </div>
             </form>
         </div>
     </div>
     <script>
     function myFunction() {
         var r = confirm("Bạn muốn cập nhật?");
         if (r == false) {
             window.location.href="index.php?controller=thongtin";
         }
     }
     </script>
</body>
</html>
