<?php
  require_once('models/data.php');
  class qltintuc_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function select(){
      $mySQL='select * from tintuc order by MaTin';
      $result=mysqli_query($this->conn,$mySQL);
      $tintucs=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $tintuc=new data_entity($row);
          $tintucs[]=$tintuc;
        }
        return $tintucs;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from tintuc');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $insert[]=$value;
          $inserts[]="'{$tta->$value}'";
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into tintuc({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function getTTbyID($MaTin)
    {
      $mySQL = "SELECT * FROM tintuc WHERE MaTin = '{$MaTin}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function update(data_entity $update,$MaTin)
    {
      $mySQL="select * from tintuc order by MaTin";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tintuc=new data_entity ($row);
      $updates=array();
      foreach($tintuc as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE tintuc set {$updates_sql} where MaTin='{$MaTin}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
    public function delete($MaTin)
    {
      $mySQL="delete from tintuc where MaTin='{$MaTin}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
