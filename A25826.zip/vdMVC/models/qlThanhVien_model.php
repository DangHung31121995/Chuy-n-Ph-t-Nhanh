<?php
  require_once('models/data.php');
  class qlthanhvien_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function select(){
      $mySQL='select * from thanhvien order by MaTV';
      $result=mysqli_query($this->conn,$mySQL);
      $thanhviens=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $thanhvien=new data_entity($row);
          $thanhviens[]=$thanhvien;
        }
        return $thanhviens;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from thanhvien');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $insert[]=$value;
          $inserts[]="'{$tta->$value}'";
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into thanhvien({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function getTTbyID($MaTV)
    {
      $mySQL = "SELECT * FROM thanhvien WHERE MaTV = '{$MaTV}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function update(data_entity $update,$MaTV)
    {
      $mySQL="select * from thanhvien order by MaTV";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $thanhvien=new data_entity ($row);
      $updates=array();
      foreach($thanhvien as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE thanhvien set {$updates_sql} where MaTV='{$MaTV}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
    public function delete($MaTV)
    {
      $mySQL="delete from thanhvien where MaTV='{$MaTV}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
