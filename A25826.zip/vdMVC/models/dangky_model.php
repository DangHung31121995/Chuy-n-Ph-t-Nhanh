<?php
  require_once('models/data.php');
  class dangky_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function check($user)
    {
      $mySQL=mysqli_query($this->conn,'select * from thanhvien');
      if($mySQL)
      {
        while($row=mysqli_fetch_array($mySQL))
        {
          $check=new data_entity($row);
          if($user->User==$check->User)
          {
            echo "<script>alert('Tên đăng nhập đã tồn tại');";
            echo "history.back(-1);</script>";
            exit;
          }
          else if($user->Email==$check->Email)
          {
            echo "<script>alert('Email đã tồn tại');";
            echo "history.back(-1);</script>";
            exit;
          }
          else if($user->SoDT==$check->SoDT)
          {
            echo "<script>alert('Số điện thoại đã tồn tại');";
            echo "history.back(-1);</script>";
            exit;
          }
        }
      }
    }
    public function insert(data_entity $user)
    {
      $mySQL=mysqli_query($this->conn,'select * from thanhvien');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $insert[]=$value;
          $inserts[]="'{$user->$value}'";
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into thanhvien({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
