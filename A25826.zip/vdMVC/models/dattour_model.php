<?php
  require_once('models/data.php');
  class dattour_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function ck($User)
    {

      $mySQL="select MaTour from ttour where MaTour in (select chitietdat.MaTour from chitietdat
      join(select MaDat from dattour where MaTV in (select MaTV from thanhvien where User='{$User}')) as tt
      on chitietdat.MaDat=tt.MaDat)";
      $result=mysqli_query($this->conn,$mySQL);
      if($result)
      {
        $tt=array();
        while($row=mysqli_fetch_array($result))
        {
          $t=new data_entity($row);
          $tt[]=$t->MaTour;
        }
        return $tt;
      }
      else {
        mysqli_error($this->conn);
      }
      return false;
    }
    public function getMaTV($User)
    {
      $mySQL="select MaTV from thanhvien where User='{$User}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from dattour');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $inserts[]="'{$tta->$value}'";
          $insert[]=$value;
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into dattour({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function inserts(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from chitietdat');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $inserts[]="'{$tta->$value}'";
          $insert[]=$value;
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into chitietdat({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function select(){
      $mySQL="select * from ttour order by MaTour DESC";
      $result=mysqli_query($this->conn,$mySQL);
      $dattours=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $dattour=new data_entity($row);
          $a=$this->getMaDD($dattour->MaDD);
          $b=$this->getMaKH($dattour->MaKH);
          $dattour->TenDD=$a->TenDD;
          $dattour->TenDiem=$b->TenDiem;
          $dattours[]=$dattour;
        }
        return $dattours;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function getMaDD($MaDD){
      $mySQL = "SELECT * FROM diemden WHERE MaDD = '{$MaDD}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function getMaKH($MaKH){
      $mySQL = "SELECT * FROM diemkh WHERE MaKH = '{$MaKH}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function getTTbyID($MaTour)
    {
      $mySQL = "SELECT * FROM ttour WHERE MaTour = '{$MaTour}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function check(data_entity $user)
    {
      $pas=md5($user->Password);
      $mySQL="select User,Password from thanhvien where User='{$user->User}'";
      $result=mysqli_query($this->conn,$mySQL);
      if((mysqli_fetch_array($result)=='null')&&$user->User!='admin')
      {
        echo "<script > alert('Tên đăng nhập không tồn tại');";
        echo "history.back(-1);</script>";
        exit;
      }
      if($user->User=='admin')
      {
        $mySQL="select User,Password,Status from admin where User='{$user->User}'";
        $result=mysqli_query($this->conn,$mySQL);
        $row=mysqli_fetch_array($result);
        $ad=new data_entity($row);
        if($pas!==$ad->Password)
        {
          echo "<script > alert('Mật khẩu không chính xác');";
          echo "history.back(-1);</script>";
          exit;
        }
        else {
          $_SESSION['Status']=$ad->Status;
          header('location:index.php?controller=qlDiemKH');
        }
      }
      else{
        $mySQL="select User,Password from thanhvien where User='{$user->User}'";
        $result=mysqli_query($this->conn,$mySQL);
        $row = mysqli_fetch_array($result);
        $u=new data_entity($row);
        if($pas!=$u->Password)
        {
          echo "<script > alert('Mật khẩu không chính xác');";
          echo "history.back(-1);</script>";
          exit;
        }
        else {
          $_SESSION['User']=$user->User;
          header('location:index.php?controller=dattour');
        }
      }
    }
  }
 ?>
