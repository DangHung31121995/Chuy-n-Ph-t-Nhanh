<?php
  require_once('models/data.php');
  class lienhe_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function check(data_entity $user)
    {
      $pas=md5($user->Password);
      $mySQL="select User,Password from thanhvien where User='{$user->User}'";
      $result=mysqli_query($this->conn,$mySQL);
      if((mysqli_fetch_array($result)=='null')&&$user->User!='admin')
      {
        echo "<script > alert('Tên đăng nhập không tồn tại');";
        echo "history.back(-1);</script>";
        exit;
      }
      if($user->User=='admin')
      {
        $mySQL="select User,Password,Status from admin where User='{$user->User}'";
        $result=mysqli_query($this->conn,$mySQL);
        $row=mysqli_fetch_array($result);
        $ad=new data_entity($row);
        if($pas!==$ad->Password)
        {
          echo "<script > alert('Mật khẩu không chính xác');";
          echo "history.back(-1);</script>";
          exit;
        }
        else {
          $_SESSION['Status']=$ad->Status;
          header('location:index.php?controller=qlDiemKH');
        }
      }
      else{
        $mySQL="select User,Password from thanhvien where User='{$user->User}'";
        $result=mysqli_query($this->conn,$mySQL);
        $row = mysqli_fetch_array($result);
        $u=new data_entity($row);
        if($pas!=$u->Password)
        {
          echo "<script > alert('Mật khẩu không chính xác');";
          echo "history.back(-1);</script>";
          exit;
        }
        else {
          $_SESSION['User']=$user->User;
          header('location:index.php?controller=lienhe');
        }
      }
    }
  }
 ?>
