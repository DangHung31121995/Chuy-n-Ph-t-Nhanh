<?php
  require_once('models/data.php');
  class qldiemden_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function select(){
      $mySQL='select * from diemden order by MaDD';
      $result=mysqli_query($this->conn,$mySQL);
      $diemdens=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $diemden=new data_entity($row);
          $diemdens[]=$diemden;
        }
        return $diemdens;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from diemden');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $inserts[]="'{$tta->$value}'";
          $insert[]=$value;
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into diemden({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function getTTbyID($MaDD)
    {
      $mySQL = "SELECT * FROM diemden WHERE MaDD = '{$MaDD}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function getLTbyID()
    {
      $mySQL="SELECT MaLoai FROM loaitour";
      $result=mysqli_query($this->conn,$mySQL);
      $data=array();
      while($row=mysqli_fetch_array($result))
      {
        $data[]=new data_entity($row);
      }
      return $data;
    }
    public function update(data_entity $update,$MaDD)
    {
      $mySQL="select * from diemden";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $diemden=new data_entity ($row);
      $updates=array();
      foreach($diemden as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE diemden set {$updates_sql} where MaDD='{$MaDD}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
    public function delete($MaDD)
    {
      $mySQL="delete from diemden where MaDD='{$MaDD}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
