<?php
  require_once('models/data.php');
  class qlTour_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function getMaKH()
    {
      $mySQL='select * from diemkh';
      $result=mysqli_query($this->conn,$mySQL);
      $MaKHs=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $MaKH=new data_entity($row);
          $MaKHs[]=$MaKH;
        }
        return $MaKHs;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function getMDD()
    {
      $mySQL='select * from diemden';
      $result=mysqli_query($this->conn,$mySQL);
      $MaKHs=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $MaKH=new data_entity($row);
          $MaKHs[]=$MaKH;
        }
        return $MaKHs;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function getML()
    {
      $mySQL='select * from loaitour';
      $result=mysqli_query($this->conn,$mySQL);
      $MaKHs=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $MaKH=new data_entity($row);
          $MaKHs[]=$MaKH;
        }
        return $MaKHs;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function select(){
      $mySQL='select * from ttour order by MaTour';
      $result=mysqli_query($this->conn,$mySQL);
      $ttours=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $ttour=new data_entity($row);
          $ttours[]=$ttour;
        }
        return $ttours;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from ttour');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $insert[]=$value;
          $inserts[]="'{$tta->$value}'";
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into ttour({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function getTTbyID($MaTour)
    {
      $mySQL = "SELECT * FROM ttour WHERE MaTour = '{$MaTour}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function update(data_entity $update,$MaTour)
    {
      $mySQL="select * from ttour order by MaTour";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $ttour=new data_entity ($row);
      $updates=array();
      foreach($ttour as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE ttour set {$updates_sql} where MaTour='{$MaTour}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
    public function delete($MaTour)
    {
      $mySQL="delete from ttour where MaTour='{$MaTour}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
