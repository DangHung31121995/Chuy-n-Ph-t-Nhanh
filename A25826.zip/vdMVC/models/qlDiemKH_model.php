<?php
  require_once('models/data.php');
  class qlDiemKH_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function select(){
      $mySQL='select * from diemkh order by MaKH';
      $result=mysqli_query($this->conn,$mySQL);
      $diemkhs=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $diemkh=new data_entity($row);
          $diemkhs[]=$diemkh;
        }
        return $diemkhs;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function insert(data_entity $tta)
    {
      $mySQL=mysqli_query($this->conn,'select * from diemkh');
      $insert=array();
      $inserts=array();
      $data=mysqli_fetch_fields($mySQL);
      foreach($data as $key=>$value)
      {
        foreach($value as $key=>$value)
        {
          $insert[]=$value;
          $inserts[]="'{$tta->$value}'";
          break;
        }
      }
      $insert=implode(',',$insert);
      $inserts=implode(',',$inserts);
      $mySQL="insert into diemkh({$insert}) value({$inserts})";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function getTTbyID($MaKH)
    {
      $mySQL = "SELECT * FROM diemkh WHERE MaKH = '{$MaKH}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function update(data_entity $update,$MaKH)
    {
      $mySQL="select * from diemkh order by MaKH";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $diemkh=new data_entity ($row);
      $updates=array();
      foreach($diemkh as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE diemkh set {$updates_sql} where MaKH='{$MaKH}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
    public function delete($MaKH)
    {
      $mySQL="delete from diemkh where MaKH='{$MaKH}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
