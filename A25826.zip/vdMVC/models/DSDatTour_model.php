<?php
  require_once('models/data.php');
  class DSDatTour_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function getMaTV($User)
    {
      $mySQL="select MaTV from thanhvien where User='{$User}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $tt=new data_entity($row);
      return $tt;
    }
    public function select(){
      $mySQL="SELECT tt.MaDat,tv.User,tv.Email,tv.SoDT,tt.NgayDat,tt.MaTour,tt.GiaTour,tt.NgayKhoiHanh from thanhvien as tv join (select dattour.NgayDat,dattour.MaTV,ttour.MaTour,ttour.GiaTour,ttour.NgayKhoiHanh,dattour.MaDat from chitietdat join dattour on chitietdat.MaDat=dattour.MaDat
join ttour on chitietdat.MaTour=ttour.MaTour) as tt on tv.MaTV=tt.MaTV";
      $result=mysqli_query($this->conn,$mySQL);
      $DSDatTours=array();
      if($result)
      {
        while($row=mysqli_fetch_array($result))
        {
          $DSDatTour=new data_entity($row);
          $DSDatTours[]=$DSDatTour;
        }
        return $DSDatTours;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function delete($MaDD)
    {
      $mySQL="delete from dattour where MaDat='{$MaDD}'";
      $result=mysqli_query($this->conn,$mySQL);
      $mySQL="delete from chitietdat where MaDat='{$MaDD}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
  }
 ?>
