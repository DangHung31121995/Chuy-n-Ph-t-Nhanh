<?php
  require_once('data.php');
  $conn=mysqli_connect('localhost','root','');
  mysqli_select_db($conn,'tour');
  $M=$_POST['MaLoai'];
  $mySQL="select * from diemden where MaLoai='{$M}'";
  $result=mysqli_query($conn,$mySQL);
  $MaDD=array();
  while($row=mysqli_fetch_array($result))
  {
    $Ma=new data_entity($row);
    $MaDD[]=$Ma;
  }
  foreach($MaDD as $key=>$value)
  {
?>
<option value="<?php echo $value->MaDD; ?>"><?php echo $value->TenDD; ?></option>
<?php } ?>
