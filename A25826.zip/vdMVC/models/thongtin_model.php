<?php
  require_once('models/data.php');
  class thongtin_model{
    var $conn;
    public function __construct(){
      $this->conn=mysqli_connect('localhost','root','')or die('khong the ket noi');
      mysqli_select_db($this->conn,'tour');
    }
    public function check($user,$Email,$SoDT)
    {
      $mySQL="select * from thanhvien where User='{$user}'";
      $result=mysqli_query($this->conn,$mySQL);
      if(!$result)
      {
        echo "<script>alert('Tên tài khoản không tồn tại');";
        echo "history.back(-1);</script>";
        exit;
      }
      $tk=new data_entity(mysqli_fetch_array($result));
      if($Email!=$tk->Email)
      {
        echo "<script>alert('Email không chính xác');";
        echo "history.back(-1);</script>";
        exit;
      }
      else if($SoDT!=$tk->SoDT)
      {
        echo "<script>alert('Số điên thoại không chính xác');";
        echo "history.back(-1);</script>";
        exit;
      }
      $pas=md5('123456');
      $mySQL="UPDATE thanhvien SET Password='{$pas}' where User='{$user}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function change($user,$pas)
    {
      $pas=md5($pas);
      $mySQL="update thanhvien set Password='{$pas}' where User='{$user}'";
      $result=mysqli_query($this->conn,$mySQL);
    }
    public function select($user){
      $mySQL="select * from thanhvien where User='{$user}'";
      $result=mysqli_query($this->conn,$mySQL);
      if($result)
      {
        $diemkh=new data_entity(mysqli_fetch_array($result));
        return $diemkh;
      }
      else {
        print mysqli_error($this->conn);
      }
      return false;
    }
    public function update(data_entity $update)
    {
      $mySQL="select * from thanhvien where User='{$update->User}'";
      $result=mysqli_query($this->conn,$mySQL);
      $row=mysqli_fetch_array($result);
      $diemkh=new data_entity ($row);
      $updates=array();
      foreach($diemkh as $key=>$value)
      {
        foreach($value as $k=>$value)
        {
          if(is_string($k))
          {
            if($update->$k!='null')
            {
              $updates[]="{$k}='{$update->$k}'";
            }
          }
        }
        break;
      }
      if(count($updates)>0)
      {
        $updates_sql=implode(',',$updates);
        $mySQL="UPDATE thanhvien set {$updates_sql} where User='{$update->User}'";
        $result=mysqli_query($this->conn,$mySQL);
      }
      echo "<script language='javascript'>alert('Cập nhật thành công')</script>";
    }
  }
 ?>
