<?php
  require_once('models/qlLoaiTour_model.php');
  class qlLoaiTour_controller{
    var $model;
    public function __construct(){
      $this->model=new qlLoaiTour_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlLoaiTour_insert.php');
            break;
          }
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from loaitour ';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              $insert->$value=$_POST["{$value}"];
              break;
            }
          }
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlLoaiTour");
          }
          break;
        case 'update':
          $MaLoai=$_GET['MaLoai'];
          $qlLoaiTour=$this->model->getTTbyID($MaLoai);
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlLoaiTour_update.php');
            break;
          }
          foreach($qlLoaiTour as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $qlLoaiTour->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $result=$this->model->update($qlLoaiTour,$MaLoai);
          header('location:index.php?controller=qlLoaiTour');
          break;
      case 'view':
        $MaLoai = $_GET['MaLoai'];
        $tt = $this->model->getTTbyID($MaLoai);
        require_once('views/qlLoaiTour_list.php');
        break;
      case 'delete':
        $MaLoai=$_GET['MaLoai'];
        $result=$this->model->delete($MaLoai);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlLoaiTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlLoaiTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
