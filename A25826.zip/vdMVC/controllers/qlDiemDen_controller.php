<?php
  require_once('models/qlDiemDen_model.php');
  class qlDiemDen_controller{
    var $model;
    public function __construct(){
      $this->model=new qlDiemDen_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $data=$this->model->getLTbyID();
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlDiemDen_insert.php');
            break;
          }
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from diemden';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              $insert->$value=$_POST["{$value}"];
              break;
            }
          }
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlDiemDen");
          }
          break;
        case 'update':
          $MaDD=$_GET['MaDD'];
          $qlDiemDen=$this->model->getTTbyID($MaDD);
          $data=$this->model->getLTbyID();
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlDiemDen_update.php');
            break;
          }
          foreach($qlDiemDen as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $qlDiemDen->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $result=$this->model->update($qlDiemDen,$MaDD);
          header('location:index.php?controller=qlDiemDen');
          break;
      case 'view':
        $MaDD = $_GET['MaDD'];
        $tt = $this->model->getTTbyID($MaDD);
        require_once('views/qlDiemDen_list.php');
        break;
      case 'delete':
        $MaDD=$_GET['MaDD'];
        $result=$this->model->delete($MaDD);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlDiemDen_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlDiemDen_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
