<?php
  require_once('models/tintuc_model.php');
  class tintuc_controller{
    var $model;
    public function __construct(){
      $this->model=new tintuc_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'view':
        $MaTin = $_GET['MaTin'];
        $tt = $this->model->getTTbyID($MaTin);
        $action=filter_input(INPUT_POST,'action');
        if(empty($action))
        {
          require_once('views/tintuc_view.php');
          break;
        }
        session_start();
        $u=array();
        $user=new data_entity($u);
        $user->User=$_POST['User'];
        $user->Password=$_POST['Password'];
        if(!$user->User||!$user->Password)
        {
          echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
          echo "history.back(-1);</script>";
          exit;
        }
        $result=$this->model->check($user,$MaTin);
        break;
      case 'list':
      default:
        $data = $this->model->select();
        $action=filter_input(INPUT_POST,'action');
        if (empty($action)) {
          require_once('views/tintuc_list.php');
          break;
        }
        session_start();
        $u=array();
        $user=new data_entity($u);
        $user->User=$_POST['User'];
        $user->Password=$_POST['Password'];
        if(!$user->User||!$user->Password)
        {
          echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
          echo "history.back(-1);</script>";
          exit;
        }
        $result=$this->model->check($user,$MaTin);
        break;
      }
    }

  }
 ?>
