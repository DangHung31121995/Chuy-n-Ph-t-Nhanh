<?php
  require_once('models/qlYKienKH_model.php');
  class qlYKienKH_controller{
    var $model;
    public function __construct(){
      $this->model=new qlYKienKH_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlYKienKH_insert.php');
            break;
          }
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from ykienkhachhang';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              $insert->$value=$_POST["{$value}"];
              break;
            }
          }
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlYKienKH");
          }
          break;
        case 'update':
          $MaYKien=$_GET['MaYKien'];
          $qlYKienKH=$this->model->getTTbyID($MaYKien);
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlYKienKH_update.php');
            break;
          }
          foreach($qlYKienKH as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $qlYKienKH->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $result=$this->model->update($qlYKienKH,$MaYKien);
          header('location:index.php?controller=qlYKienKH');
          break;
      case 'view':
        $MaYKien = $_GET['MaYKien'];
        $tt = $this->model->getTTbyID($MaYKien);
        require_once('views/qlYKienKH_list.php');
        break;
      case 'delete':
        $MaYKien=$_GET['MaYKien'];
        $result=$this->model->delete($MaYKien);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlYKienKH_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlYKienKH_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
