<?php
  require_once('models/ykien_model.php');
  class ykien_controller{
    var $model;
    public function __construct(){
      $this->model=new ykien_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'list':
      default:
        $action=filter_input(INPUT_POST,'action');
        if (empty($action)) {
          require_once('views/ykien_list.php');
          break;
        }
        if(isset($_POST['User']))
        {
          session_start();
          $u=array();
          $user=new data_entity($u);
          $user->User=$_POST['User'];
          $user->Password=$_POST['Password'];
          if(!$user->User||!$user->Password)
          {
            echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
            echo "history.back(-1);</script>";
            exit;
          }
          $result=$this->model->check($user);
        }
        else{
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from ykienkhachhang';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              if($value!='MaYKien')
              {
                if($_POST["{$value}"]=='')
                {
                  echo "<script>alert('Bạn chưa nhập đủ thông tin');";
                  echo "history.back(-1);</script>";
                  exit;
              }
              $insert->$value=$_POST["{$value}"];
              }
              break;
            }
          }
          $insert->MaYKien='null';
          $result=$this->model->insert($insert);
          if($result)
          {
            echo "<script>alert('Cảm ơn bạn đã góp ý cho chúng tôi');";
            echo "history.back(-1);</script>";
            exit;
          }
        }
        break;
      }
    }

  }
 ?>
