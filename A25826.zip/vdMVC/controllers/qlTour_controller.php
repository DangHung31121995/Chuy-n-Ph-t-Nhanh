<?php
  require_once('models/qlTour_model.php');
  class qlTour_controller{
    var $model;
    public function __construct(){
      $this->model=new qlTour_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'getMaDD':
          if(!empty($_POST['MaLoai']))
          {
            $MaDD=$this->model->getMDD($_POST['MaLoai']);
          }
          break;
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          $MaKH=$this->model->getMaKH();
          $MaLoai=$this->model->getML();
          if (empty($action_POST)) {
            require_once('views/qlTour_insert.php');
            break;
          }
          $a=$_POST['Ten'];
          $a=htmlspecialchars($a, ENT_COMPAT);
          #$a=html_entity_decode($a, ENT_QUOTES, 'UTF-8');
          $t=array();
          $Anh_d='views/images/';
          $Anh=$Anh_d.basename($_FILES['AnhT']['name']);
          $insert=new data_entity($t);
          $mySQL='select * from ttour';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              if($value!='NoiDung'&&$value!='Anh')
              {
                $insert->$value=$_POST["{$value}"];
              }
              break;
            }
          }
          $insert->NoiDung=$a;
          $insert->Anh=$Anh;
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlTour");
          }
          break;
        case 'update':
          $MaTour=$_GET['MaTour'];
          $qlTour=$this->model->getTTbyID($MaTour);
          $MaKH=$this->model->getMaKH();
          $MaLoai=$this->model->getML();
          $DD=$this->model->getMDD();
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlTour_update.php');
            break;
          }
          $a=$_POST['Ten'];
          $a=htmlspecialchars($a, ENT_COMPAT);
          if($_FILES['AnhT']['name'])
          {
            $Anh_d='views/images/';
            $Anh=$Anh_d.basename($_FILES['AnhT']['name']);
          }
          $Anh=$qlTinTuc->Anh;
          #$a=html_entity_decode($a, ENT_QUOTES, 'UTF-8');
          foreach($qlTour as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                if($k!='NoiDung'&&$k!='Anh')
                {
                  $qlTour->$k=$_POST["{$k}"];
                }
              }
            }
            break;
          }
          $qlTour->Anh=$Anh;
          $qlTour->NoiDung=$a;
          $result=$this->model->update($qlTour,$MaTour);
          header('location:index.php?controller=qlTour');
          break;
      case 'view':
        $MaTour = $_GET['MaTour'];
        $tt = $this->model->getTTbyID($MaTour);
        require_once('views/qlTour_list.php');
        break;
      case 'delete':
        $MaTour=$_GET['MaTour'];
        $result=$this->model->delete($MaTour);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
