<?php
  require_once('models/DSDatTour_model.php');
  class DSDatTour_controller{
    var $model;
    public function __construct(){
      $this->model=new DSDatTour_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'update':
          $MaDD=$_GET['MaDD'];
          $DSDatTour=$this->model->getTTbyID($MaDD);
          $data=$this->model->getLTbyID();
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/DSDatTour_update.php');
            break;
          }
          foreach($DSDatTour as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $DSDatTour->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $result=$this->model->update($DSDatTour,$MaDD);
          header('location:index.php?controller=DSDatTour');
          break;
      case 'delete':
        $MaDD=$_GET['MaDat'];
        $result=$this->model->delete($MaDD);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/DSDatTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/DSDatTour_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
