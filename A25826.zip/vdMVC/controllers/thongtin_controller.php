<?php
  require_once('models/thongtin_model.php');
  class thongtin_controller{
    var $model;
    public function __construct(){
      $this->model=new thongtin_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'Forgot':
        $action_POST = isset($_POST['action'])?$_POST['action']:'';
        if (empty($action_POST)) {
          require_once('views/thongtin_Forgot.php');
          break;
        }
        if($_POST['User']==''||$_POST['Email']==''||$_POST['SoDT']=='')
        {
          echo "<script>alert('Vui lòng nhập đầy đủ thông tin');";
          echo "history.back(-1);</script>";
          exit;
        }
        $user=$_POST['User'];
        $email=$_POST['Email'];
        $SoDT=$_POST['SoDT'];
        $this->model->check($user,$email,$SoDT);
        echo "<script>alert('Mật khẩu của bạn là 123456 vui lòng đăng nhập và đổi lại');";
        echo "window.location.href='index.php?controller=trangchu';</script>";
        break;
      case 'pass':
          session_start();
          $user=$_SESSION['User'];
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/thongtin_pass.php');
            break;
          }
          $pas=$_POST['Pas'];
          $pas1=$_POST['Pas1'];
          if($pas!=$pas1)
          {
            echo "<script>alert('Nhập lại mật khẩu không chính xác');";
            echo "history.back(-1);</script>";
            exit;
          }
          $result=$this->model->change($user,$pas);
          echo "<script>alert('Thay đổi thành công');";
          echo "window.location.href='index.php?controller=trangchu';</script>";
          break;
      case 'list':
      default:
        session_start();
        $user=$_SESSION['User'];
        $data = $this->model->select($user);
        $action_POST = isset($_POST['action'])?$_POST['action']:'';
        if (empty($action_POST)) {
          require_once('views/thongtin_list.php');
          break;
        }
        foreach($data as $key=>$value)
        {
          foreach($value as $k=>$value)
          {
            if(isset($_POST["{$k}"]))
            {
                $data->$k=$_POST["{$k}"];
            }
          }
          break;
        }
        $result=$this->model->update($data);
        header('location:index.php?controller=thongtin');
        break;
      }
    }
  }
 ?>
