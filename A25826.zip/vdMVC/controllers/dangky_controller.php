<?php
  require_once('models/dangky_model.php');
  class dangky_controller{
    var $model;
    public function __construct(){
      $this->model=new dangky_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'logout':
          unset($_SESSION['user']);
          header('location:index.php?controller=trangchu');
          break;
      case 'insert':
        $action_POST = isset($_POST['action'])?$_POST['action']:'';
        if (empty($action_POST)) {
          require_once('views/dangky_insert.php');
          break;
        }
        $t=array();
        $insert=new data_entity($t);
        $mySQL='select * from thanhvien';
        $result=mysqli_query($this->model->conn,$mySQL);
        $data=mysqli_fetch_fields($result);
        foreach($data as $key=>$value)
        {
          foreach($value as $key=>$value)
          {
            if($value!='MaTV')
            {
              if($_POST["{$value}"]=='')
              {
                echo "<script>alert('Bạn chưa nhập đủ thông tin');";
                echo "history.back(-1);</script>";
                exit;
              }
              $insert->$value=$_POST["{$value}"];
            }
            break;
          }
        }
        $result=$this->model->check($insert);
        $insert->MaTV='null';
        $insert->Password=md5($insert->Password);
        $result=$this->model->insert($insert);
        if(!$result)
        {
          echo "<script>alert('Đăng ký thành công');";
          echo "window.location.href='index.php?controller=trangchu';</script>";
        }
        break;
      default:
        break;
      }
    }

  }
 ?>
