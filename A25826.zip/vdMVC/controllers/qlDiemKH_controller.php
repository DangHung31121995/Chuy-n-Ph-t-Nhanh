<?php
  require_once('models/qlDiemKH_model.php');
  class qlDiemKH_controller{
    var $model;
    public function __construct(){
      $this->model=new qlDiemKH_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlDiemKH_insert.php');
            break;
          }
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from diemkh';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              $insert->$value=$_POST["{$value}"];
              break;
            }
          }
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlDiemKH");
          }
          break;
        case 'update':
          $MaKH=$_GET['MaKH'];
          $qlDiemKH=$this->model->getTTbyID($MaKH);
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlDiemKH_update.php');
            break;
          }
          foreach($qlDiemKH as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $qlDiemKH->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $result=$this->model->update($qlDiemKH,$MaKH);
          header('location:index.php?controller=qlDiemKH');
          break;
      case 'view':
        $MaKH = $_GET['MaKH'];
        $tt = $this->model->getTTbyID($MaKH);
        require_once('views/qlDiemKH_list.php');
        break;
      case 'delete':
        $MaKH=$_GET['MaKH'];
        $result=$this->model->delete($MaKH);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlDiemKH_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlDiemKH_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
