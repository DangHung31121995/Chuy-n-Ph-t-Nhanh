<?php
  require_once('models/trangchu_model.php');
  class trangchu_controller{
    var $model;
    public function __construct(){
      $this->model=new trangchu_model();
    }
    public function run(){
      $action = filter_input(INPUT_GET,'action');
  		$action = $action==NULL?'list':$action;
      switch($action) {
        case 'search';
          session_start();
          $name=$_GET['ten'];
          $t=$this->model->search($name);
          $action_post=filter_input(INPUT_POST,'action');
          if(empty($action_post))
          {
            require_once('views/timtour_list.php');
            break;
          }
          $u=array();
          $user=new data_entity($u);
          $user->User=$_POST['User'];
          $user->Password=$_POST['Password'];
          if(!$user->User||!$user->Password)
          {
            echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
            echo "history.back(-1);</script>";
            exit;
          }
          $result=$this->model->check($user,$name);
          break;
        case 'logout':
          session_start();
          if(isset($_SESSION['User']))
          {
            unset($_SESSION['User']);
          }
            else if(isset($_SESSION['Status'])){
            unset($_SESSION['Status']);
          }

          header('location:index.php?controller=trangchu');
          break;
        case 'list':
        default:
          session_start();
          $action_post=filter_input(INPUT_POST,'action');
          $t=$this->model->getTT();
          $tour=$this->model->gettour();
          if(empty($action_post))
          {
            require_once('views/trangchu.php');
            break;
          }
          $u=array();
          $user=new data_entity($u);
          if(isset($_POST['User']))
          {
            $user->User=$_POST['User'];
            $user->Password=$_POST['Password'];
            if(!$user->User||!$user->Password)
            {
              echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
              echo "history.back(-1);</script>";
              exit;
            }
            $name=array();
            $result=$this->model->check($user,$name);
          }
          else {
            $name=$_POST['TenDiem'];
            if($name=='')
            {
              echo "<script>alert('Bạn chưa nhập tên điểm đến');";
              echo "history.back(-1)</script>";
              exit;
            }
            header("location:index.php?controller=trangchu&action=search&ten=$name");
          }
          break;
    }
    }

  }
 ?>
