<?php
  require_once('models/lienhe_model.php');
  class lienhe_controller{
    var $model;
    public function __construct(){
      $this->model=new lienhe_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'list':
      default:
        $action=filter_input(INPUT_POST,'action');
        if (empty($action)) {
          require_once('views/lienhe_list.php');
          break;
        }
        session_start();
        $u=array();
        $user=new data_entity($u);
        $user->User=$_POST['User'];
        $user->Password=$_POST['Password'];
        if(!$user->User||!$user->Password)
        {
          echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
          echo "history.back(-1);</script>";
          exit;
        }
        $result=$this->model->check($user);
        break;
      }
    }

  }
 ?>
