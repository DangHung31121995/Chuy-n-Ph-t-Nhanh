<?php
  require_once('models/qlTinTuc_model.php');
  class qlTinTuc_controller{
    var $model;
    public function __construct(){
      $this->model=new qlTinTuc_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlTinTuc_insert.php');
            break;
          }
          $Anh_d='views/images/';
          $Anh=$Anh_d.basename($_FILES['AnhT']['name']);
          $a=$_POST['Ten'];
          $a=htmlspecialchars($a, ENT_COMPAT);
          #$a=html_entity_decode($a, ENT_QUOTES, 'UTF-8');
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from tintuc';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              if($value!='NoiDung'&&$value!='Anh')
              {
                $insert->$value=$_POST["{$value}"];
              }
              break;
            }
          }
          $insert->Anh=$Anh;
          $insert->NoiDung=$a;
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlTinTuc");
          }
          break;
        case 'update':
          $MaTin=$_GET['MaTin'];
          $qlTinTuc=$this->model->getTTbyID($MaTin);
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlTinTuc_update.php');
            break;
          }
          if($_FILES['AnhT']['name'])
          {
            $Anh_d='views/images/';
            $Anh=$Anh_d.basename($_FILES['AnhT']['name']);
          }
          $Anh=$qlTinTuc->Anh;
          $a=$_POST['Ten'];
          $a=htmlspecialchars($a, ENT_COMPAT);
          foreach($qlTinTuc as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                if($k!='NoiDung'&&$k!='Anh')
                {
                  $qlTinTuc->$k=$_POST["{$k}"];
                }
              }
            }
            break;
          }
          $qlTinTuc->Anh=$Anh;
          $qlTinTuc->NoiDung=$a;
          $result=$this->model->update($qlTinTuc,$MaTin);
          header('location:index.php?controller=qlTinTuc');
          break;
      case 'view':
        $MaTin = $_GET['MaTin'];
        $tt = $this->model->getTTbyID($MaTin);
        require_once('views/qlTinTuc_list.php');
        break;
      case 'delete':
        $MaTin=$_GET['MaTin'];
        $result=$this->model->delete($MaTin);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlTinTuc_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlTinTuc_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
