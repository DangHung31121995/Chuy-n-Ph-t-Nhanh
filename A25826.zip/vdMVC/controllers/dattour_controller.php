<?php
  require_once('models/dattour_model.php');
  class dattour_controller{
    var $model;
    public function __construct(){
      $this->model=new dattour_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
      case 'view':
        $MaTin = $_GET['MaTour'];
        $tt = $this->model->getTTbyID($MaTin);
        $a=$this->model->getMaDD($tt->MaDD);
        $b=$this->model->getMaKH($tt->MaKH);
        $tt->TenDD=$a->TenDD;
        $tt->TenDiem=$b->TenDiem;
        $action_POST = isset($_POST['action'])?$_POST['action']:'';
        if (empty($action_POST)) {
          require_once('views/dattour_view.php');
          break;
        }
        $MaT=$_POST['MaTour'];
        $User=$_POST['UserName'];
        $time=gmdate("Y-m-d H:i:s");
        $MaTV=$this->model->getMaTV($User);
        $t=array();
        $tt=new data_entity($t);
        $tt->MaDat='null';
        $tt->MaTV=$MaTV->MaTV;
        $tt->NgayDat=$time;
        $result=$this->model->insert($tt);
        $result=mysqli_query($this->model->conn,"select MaDat from dattour order by MaDat DESC");
        $row=mysqli_fetch_array($result);
        $t=array();
        $tt=new data_entity($t);
        $tt->MaDat=$row['MaDat'];
        $tt->MaTour=$MaT;
        $tt->CapKS='4*';
        $result=$this->model->inserts($tt);
        header('location:index.php?controller=dattour');
        break;
      case 'list':
      default:
        session_start();
        $data = $this->model->select();
        if(isset($_SESSION['User'])){
          $a=$_SESSION['User'];
          $d=$this->model->ck($a);
        }
        $action=filter_input(INPUT_POST,'action');
        if(empty($action))
        {
          require_once('views/dattour_list.php');
          break;
        }
        session_start();
        $u=array();
        $user=new data_entity($u);
        $user->User=$_POST['User'];
        $user->Password=$_POST['Password'];
        if(!$user->User||!$user->Password)
        {
          echo "<script> alert('Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu');";
          echo "history.back(-1);</script>";
          exit;
        }
        $result=$this->model->check($user);
        break;
      }
    }

  }
 ?>
