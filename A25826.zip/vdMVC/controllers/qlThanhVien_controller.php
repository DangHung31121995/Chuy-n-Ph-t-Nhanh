<?php
  require_once('models/qlThanhVien_model.php');
  class qlThanhVien_controller{
    var $model;
    public function __construct(){
      $this->model=new qlThanhVien_model();
    }
    public function run(){
      $action=filter_input(INPUT_GET,'action');
      $action = $action==NULL?'list':$action;
      switch ($action) {
        case 'insert':
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlThanhVien_insert.php');
            break;
          }
          $t=array();
          $insert=new data_entity($t);
          $mySQL='select * from thanhvien';
          $result=mysqli_query($this->model->conn,$mySQL);
          $data=mysqli_fetch_fields($result);
          foreach($data as $key=>$value)
          {
            foreach($value as $key=>$value)
            {
              $insert->$value=$_POST["{$value}"];
              break;
            }
          }
          $result=$this->model->insert($insert);
          if(!$result)
          {
            header("Location: index.php?controller=qlThanhVien");
          }
          break;
        case 'update':
          $MaTV=$_GET['MaTV'];
          $qlThanhVien=$this->model->getTTbyID($MaTV);
          $action_POST = isset($_POST['action'])?$_POST['action']:'';
          if (empty($action_POST)) {
            require_once('views/qlThanhVien_update.php');
            break;
          }
          foreach($qlThanhVien as $key=>$value)
          {
            foreach($value as $k=>$value)
            {
              if(is_string($k))
              {
                  $qlThanhVien->$k=$_POST["{$k}"];
              }
            }
            break;
          }
          $qlThanhVien->Password=md5($qlThanhVien->Password);
          $result=$this->model->update($qlThanhVien,$MaTV);
          header('location:index.php?controller=qlThanhVien');
          break;
      case 'view':
        $MaTV = $_GET['MaTV'];
        $tt = $this->model->getTTbyID($MaTV);
        require_once('views/qlThanhVien_list.php');
        break;
      case 'delete':
        $MaTV=$_GET['MaTV'];
        $result=$this->model->delete($MaTV);
        $data=$this->model->select();
        if($data !==false)
        {
          require_once('views/qlThanhVien_list.php');
        }
        else {
          print "Error";
        }
        break;
      case 'list':
      default:
        $data = $this->model->select();
        if ($data !==false) {
          require_once('views/qlThanhVien_list.php');
        }
        else {
          print "Error";
        }
        break;
      }
    }

  }
 ?>
